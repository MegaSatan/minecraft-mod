package mod.creativetabs;

import mod.ModElements;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class MCrafterzzModToolsTab extends CreativeTabs {

	public MCrafterzzModToolsTab(String label) {
		super(label);
	}

	@Override
	public Item getTabIconItem() {
		return ModElements.amethyst_pickaxe;
	}

}
