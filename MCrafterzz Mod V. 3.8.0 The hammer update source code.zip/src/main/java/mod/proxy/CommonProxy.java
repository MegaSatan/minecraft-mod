package mod.proxy;

import java.io.File;

import mod.Main;
import mod.ModElements;
import mod.ModElementsSmallerBlocks;
import mod.commands.CommandMCrafterzzMod;
import mod.commands.CommandMM;
import mod.commands.CommandSetBlocks;
import mod.config.Config;
import mod.worldgen.ModFlowerGenerator;
import mod.worldgen.ModOreGenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.network.IGuiHandler;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CommonProxy {

	public void preInit(FMLPreInitializationEvent event) {
		FMLCommonHandler.instance().bus().register(Config.instance);
		Config.init(event.getSuggestedConfigurationFile());
		Config.syncConfig();
		ModElements.createBlocksAndItems();
		ModElements.registerItemsAndBlocks();
		ModElementsSmallerBlocks.createBlocksAndItems();
		ModElementsSmallerBlocks.registerItemsAndBlocks();
		ModElements.setupRepairItemForToolsAndArmour();
		ModElements.removeCrafting();
		ModElements.crafting();
		ModElements.registerAchievements();
		ModElements.registerStats();
		ModElements.registerGuiHandlers();
		ModElements.registerEventHandlers();
		ModElementsSmallerBlocks.crafting();
	}

	public void init(FMLInitializationEvent event) {
		ModElements.registerRenders();
		ModElements.registerOreDictionary();
		ModElementsSmallerBlocks.registerRenders();
		GameRegistry.registerWorldGenerator(new ModOreGenerator(), 0);
		GameRegistry.registerWorldGenerator(new ModFlowerGenerator(), 100);
		ClientCommandHandler.instance.registerCommand(new CommandMCrafterzzMod());
		ClientCommandHandler.instance.registerCommand(new CommandMM());
		ClientCommandHandler.instance.registerCommand(new CommandSetBlocks());
	}

	public void postInit(FMLPostInitializationEvent event) {
	}

}
