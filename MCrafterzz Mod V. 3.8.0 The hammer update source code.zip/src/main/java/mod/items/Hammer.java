package mod.items;

import java.util.Collections;
import java.util.Set;

import com.google.common.collect.Sets;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class Hammer extends ItemTool {

	public static float attack_speed = -2.8F;
	public static float base_damage = 3.0F;

	public Hammer(ToolMaterial toolMaterial, int durabillity) {
		super(base_damage, attack_speed, toolMaterial, Collections.emptySet());
		this.setHarvestLevel("pickaxe", toolMaterial.getHarvestLevel());
		this.setMaxDamage(durabillity);
	}

	@Override
	public boolean onBlockStartBreak(ItemStack itemStack, BlockPos pos, EntityPlayer player) {
		if (player.isCreative()) {
			EnumFacing facing = player.getHorizontalFacing();
			World worldIn = player.getEntityWorld();
			IBlockState state = worldIn.getBlockState(pos);
			Block block = state.getBlock();
			float headYaw = player.getRotationYawHead();
			if (facing == facing.NORTH) {
				for (int x = (pos.getX() - 1); x < (pos.getX() + 2); x++) {
					for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
						if (!worldIn.isAirBlock(new BlockPos(x, y, pos.getZ()))
								&& ((double) state.getBlockHardness(worldIn, new BlockPos(x, y, pos.getZ())) != 0.0D)) {
							if (state.getBlock().isToolEffective("pickaxe", state)) {
								itemStack.damageItem(1, player);
							} else {
								itemStack.damageItem(3, player);
							}
						}
						if (itemStack.getItem().getHarvestLevel(itemStack, "pickaxe") >= state.getBlock()
								.getHarvestLevel(state)) {
							worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
						} else {
							worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
						}
					}
				}
			}
			if (facing == facing.SOUTH) {
				for (int x = (pos.getX() - 1); x < (pos.getX() + 2); x++) {
					for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
						if (!worldIn.isAirBlock(new BlockPos(x, y, pos.getZ()))
								&& ((double) state.getBlockHardness(worldIn, new BlockPos(x, y, pos.getZ())) != 0.0D)) {
							if (state.getBlock().isToolEffective("pickaxe", state)) {
								itemStack.damageItem(1, player);
							} else {
								itemStack.damageItem(3, player);
							}
						}
						if (itemStack.getItem().getHarvestLevel(itemStack, "pickaxe") >= state.getBlock()
								.getHarvestLevel(state)) {
							worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
						} else {
							worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
						}
					}
				}
			}
			if (facing == facing.EAST) {
				for (int z = (pos.getZ() - 1); z < (pos.getZ() + 2); z++) {
					for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
						if (!worldIn.isAirBlock(new BlockPos(pos.getX(), y, z))
								&& ((double) state.getBlockHardness(worldIn, new BlockPos(pos.getX(), y, z)) != 0.0D)) {
							if (state.getBlock().isToolEffective("pickaxe", state)) {
								itemStack.damageItem(1, player);
							} else {
								itemStack.damageItem(3, player);
							}
						}
						if (itemStack.getItem().getHarvestLevel(itemStack, "pickaxe") >= state.getBlock()
								.getHarvestLevel(state)) {
							worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
						} else {
							worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
						}
					}
				}
			}
			if (facing == facing.WEST) {
				for (int z = (pos.getZ() - 1); z < (pos.getZ() + 2); z++) {
					for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
						if (!worldIn.isAirBlock(new BlockPos(pos.getX(), y, z))
								&& ((double) state.getBlockHardness(worldIn, new BlockPos(pos.getX(), y, z)) != 0.0D)) {
							if (state.getBlock().isToolEffective("pickaxe", state)) {
								itemStack.damageItem(1, player);
							} else {
								itemStack.damageItem(3, player);
							}
						}
						if (itemStack.getItem().getHarvestLevel(itemStack, "pickaxe") >= state.getBlock()
								.getHarvestLevel(state)) {
							worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
						} else {
							worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos,
			EntityLivingBase entityLiving) {
		EnumFacing facing = entityLiving.getHorizontalFacing();
		Block block = state.getBlock();
		float headYaw = entityLiving.getRotationYawHead();
		if (facing == facing.NORTH) {
			for (int x = (pos.getX() - 1); x < (pos.getX() + 2); x++) {
				for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
					if (!worldIn.isAirBlock(new BlockPos(x, y, pos.getZ()))
							&& ((double) state.getBlockHardness(worldIn, new BlockPos(x, y, pos.getZ())) != 0.0D)) {
						if (state.getBlock().isToolEffective("pickaxe", state)) {
							stack.damageItem(1, entityLiving);
						} else {
							stack.damageItem(3, entityLiving);
						}
					}
					if (stack.getItem().getHarvestLevel(stack, "pickaxe") >= state.getBlock().getHarvestLevel(state)) {
						worldIn.destroyBlock(new BlockPos(x, y, pos.getZ()), true);
					} else {
						worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
					}
				}
			}
		}
		if (facing == facing.SOUTH) {
			for (int x = (pos.getX() - 1); x < (pos.getX() + 2); x++) {
				for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
					if (!worldIn.isAirBlock(new BlockPos(x, y, pos.getZ()))
							&& ((double) state.getBlockHardness(worldIn, new BlockPos(x, y, pos.getZ())) != 0.0D)) {
						if (state.getBlock().isToolEffective("pickaxe", state)) {
							stack.damageItem(1, entityLiving);
						} else {
							stack.damageItem(3, entityLiving);
						}
					}
					if (stack.getItem().getHarvestLevel(stack, "pickaxe") >= state.getBlock().getHarvestLevel(state)) {
						worldIn.destroyBlock(new BlockPos(x, y, pos.getZ()), true);
					} else {
						worldIn.setBlockToAir(new BlockPos(x, y, pos.getZ()));
					}
				}
			}
		}
		if (facing == facing.EAST) {
			for (int z = (pos.getZ() - 1); z < (pos.getZ() + 2); z++) {
				for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
					if (!worldIn.isAirBlock(new BlockPos(pos.getX(), y, z))
							&& ((double) state.getBlockHardness(worldIn, new BlockPos(pos.getX(), y, z)) != 0.0D)) {
						if (state.getBlock().isToolEffective("pickaxe", state)) {
							stack.damageItem(1, entityLiving);
						} else {
							stack.damageItem(3, entityLiving);
						}
					}
					if (stack.getItem().getHarvestLevel(stack, "pickaxe") >= state.getBlock().getHarvestLevel(state)) {
						worldIn.destroyBlock(new BlockPos(pos.getX(), y, z), true);
					} else {
						worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
					}
				}
			}
		}
		if (facing == facing.WEST) {
			for (int z = (pos.getZ() - 1); z < (pos.getZ() + 2); z++) {
				for (int y = (pos.getY() - 1); y < (pos.getY() + 2); y++) {
					if (!worldIn.isAirBlock(new BlockPos(pos.getX(), y, z))
							&& ((double) state.getBlockHardness(worldIn, new BlockPos(pos.getX(), y, z)) != 0.0D)) {
						if (state.getBlock().isToolEffective("pickaxe", state)) {
							stack.damageItem(1, entityLiving);
						} else {
							stack.damageItem(3, entityLiving);
						}
					}
					if (stack.getItem().getHarvestLevel(stack, "pickaxe") >= state.getBlock().getHarvestLevel(state)) {
						worldIn.destroyBlock(new BlockPos(pos.getX(), y, z), true);
					} else {
						worldIn.setBlockToAir(new BlockPos(pos.getX(), y, z));
					}
				}
			}
		}
		return true;
	}

	@Override
	public boolean hitEntity(ItemStack itemStack, EntityLivingBase target, EntityLivingBase attacker) {
		itemStack.damageItem(1, attacker);
		return true;
	}

}
