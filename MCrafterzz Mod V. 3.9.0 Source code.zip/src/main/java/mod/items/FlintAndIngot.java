package mod.items;

import net.minecraft.item.ItemFlintAndSteel;

public class FlintAndIngot extends ItemFlintAndSteel {

	public FlintAndIngot(int durabillity) {
		this.setMaxDamage(durabillity);
	}

}
