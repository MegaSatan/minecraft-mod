package mod;

import mod.blocks.ModBars;
import mod.blocks.ModBlock;
import mod.blocks.ModButton;
import mod.blocks.ModColourBlock;
import mod.blocks.ModColourChangingClass;
import mod.blocks.ModCrusher;
import mod.blocks.ModDeathBlock;
import mod.blocks.ModFence;
import mod.blocks.ModFenceGate;
import mod.blocks.ModFlower;
import mod.blocks.ModGlowingAir;
import mod.blocks.ModGlowingColourBlock;
import mod.blocks.ModIronChest;
import mod.blocks.ModPresureplate;
import mod.blocks.ModStairs;
import mod.blocks.ModTrapDoor;
import mod.blocks.ModWall;
import mod.config.Config;
import mod.creativetabs.MCrafterzzModBuildingTab;
import mod.creativetabs.MCrafterzzModMapMakingTab;
import mod.creativetabs.MCrafterzzModSmallerBuildingBlocksTab;
import mod.creativetabs.MCrafterzzModTab;
import mod.creativetabs.MCrafterzzModToolsTab;
import mod.creativetabs.MCrafterzzModWorkInProgressTab;
import mod.creativetabs.MCrafterzzModWorldTab;
import mod.gui.GuiHandlerIronChest;
import mod.items.Armour;
import mod.items.Axe;
import mod.items.Bow;
import mod.items.Hoe;
import mod.items.Multitool;
import mod.items.Pickaxe;
import mod.items.Shears;
import mod.items.Shield;
import mod.items.Shovel;
import mod.items.Sword;
import mod.tileentitys.TileEntityIronChest;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockGlass;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Achievement;
import net.minecraft.stats.StatBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.common.AchievementPage;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModElements {

	// Creative tab
	public static MCrafterzzModTab creativeTab = new MCrafterzzModTab("creativeTab");
	public static MCrafterzzModToolsTab creativeTabTools = new MCrafterzzModToolsTab("creativeTabTools");
	public static MCrafterzzModBuildingTab creativeTabBuilding = new MCrafterzzModBuildingTab("creativeTabBuilding");
	public static MCrafterzzModMapMakingTab creativeTabMapMaking = new MCrafterzzModMapMakingTab(
			"creativeTabMapMaking");
	public static MCrafterzzModWorkInProgressTab creativeTabWorkInProgress = new MCrafterzzModWorkInProgressTab(
			"creativeTabWorkInProgress");
	public static MCrafterzzModWorldTab creativeTabWorld = new MCrafterzzModWorldTab("creativeTabWorld");
	public static MCrafterzzModSmallerBuildingBlocksTab creativeTabSmallerBuildingBlocks = new MCrafterzzModSmallerBuildingBlocksTab(
			"creativeTabSmallerBuildingBlocks");
	// Achievements
	public static Achievement copperMiner;
	public static Achievement tinMiner;
	public static Achievement amethystMiner;
	public static Achievement bronzeCreator;
	public static Achievement diamondUpgrade;
	public static Achievement amethystUpgrade;
	public static Achievement theOpTool;
	public static Achievement moreFlowers;
	// Stats
	public static StatBase open_crusher_gui;
	// Tool and armour materials
	public static ToolMaterial opTool = EnumHelper.addToolMaterial("op", 4, 0, 100, 98, 100);
	public static ToolMaterial amethystTool = EnumHelper.addToolMaterial("amethyst", 4, 2000, 9, 4, 15);
	public static ToolMaterial jadeTool = EnumHelper.addToolMaterial("jade", 4, 2000, 9, 4, 15);
	public static ToolMaterial copperTool = EnumHelper.addToolMaterial("copper", 1, 170, 5.0F, 1, 15);
	public static ToolMaterial bronzeTool = EnumHelper.addToolMaterial("bronze", 2, 250, 6.5F, 2, 15);
	public static ArmorMaterial amethystArmour = EnumHelper.addArmorMaterial("amethyst", "mm:amethyst", 42,
			new int[] { 4, 9, 5, 4 }, 15, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0);
	public static ArmorMaterial jadeArmour = EnumHelper.addArmorMaterial("jade", "mm:jade", 42,
			new int[] { 4, 9, 5, 4 }, 15, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0);
	public static ArmorMaterial copperArmour = EnumHelper.addArmorMaterial("copper", "mm:copper", 13,
			new int[] { 2, 7, 4, 1 }, 15, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0);
	public static ArmorMaterial bronzeArmour = EnumHelper.addArmorMaterial("bronze", "mm:bronze", 16,
			new int[] { 3, 6, 4, 2 }, 15, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0);
	// Damage sources
	public static DamageSource death_block;
	// Mineral ores
	public static Block amethyst_ore;
	public static Block jade_ore;
	public static Block copper_ore;
	public static Block tin_ore;
	// Mineral blocks
	public static Block amethyst_block;
	public static Block jade_block;
	public static Block copper_block;
	public static Block tin_block;
	public static Block bronze_block;
	// Minerals
	public static Item amethyst;
	public static Item jade;
	public static Item copper_ingot;
	public static Item tin_ingot;
	public static Item bronze_ingot;
	// Tools
	public static Item stone_shears;
	public static Item gold_shears;
	public static Item diamond_shears;
	public static Item diamond_multitool;
	public static Item op_multitool;
	public static Item amethyst_pickaxe;
	public static Item amethyst_axe;
	public static Item amethyst_shovel;
	public static Item amethyst_hoe;
	public static Item amethyst_multitool;
	public static Item amethyst_shears;
	public static Item jade_pickaxe;
	public static Item jade_axe;
	public static Item jade_shovel;
	public static Item jade_hoe;
	public static Item jade_multitool;
	public static Item jade_shears;
	public static Item copper_pickaxe;
	public static Item copper_axe;
	public static Item copper_shovel;
	public static Item copper_hoe;
	public static Item copper_multitool;
	public static Item copper_shears;
	public static Item bronze_pickaxe;
	public static Item bronze_axe;
	public static Item bronze_shovel;
	public static Item bronze_hoe;
	public static Item bronze_multitool;
	public static Item bronze_shears;
	// Weapons
	public static Item stone_bow;
	public static Item iron_bow;
	public static Item gold_bow;
	public static Item diamond_bow;
	public static Item amethyst_sword;
	public static Item jade_sword;
	public static Item jade_bow;
	public static Item amethyst_bow;
	public static Item copper_sword;
	public static Item copper_bow;
	public static Item bronze_sword;
	public static Item bronze_bow;
	public static Item op_bow;
	// Shields
	public static Item stone_shield;
	public static Item iron_shield;
	public static Item gold_shield;
	public static Item diamond_shield;
	public static Item copper_shield;
	public static Item bronze_shield;
	public static Item jade_shield;
	public static Item amethyst_shield;
	// Armour
	public static Item amethyst_helmet;
	public static Item amethyst_chestplate;
	public static Item amethyst_leggings;
	public static Item amethyst_boots;
	public static Item jade_helmet;
	public static Item jade_chestplate;
	public static Item jade_leggings;
	public static Item jade_boots;
	public static Item copper_helmet;
	public static Item copper_chestplate;
	public static Item copper_leggings;
	public static Item copper_boots;
	public static Item bronze_helmet;
	public static Item bronze_chestplate;
	public static Item bronze_leggings;
	public static Item bronze_boots;
	// Chests
	public static Block iron_chest;
	// public static Block gold_chest;
	// public static Block diamond_chest;
	// public static Block amethyst_chest;
	// Doors
	public static Block copper_door;
	public static Block tin_door;
	public static Block bronze_door;
	public static Block amethyst_door;
	public static Item copper_door_item;
	public static Item tin_door_item;
	public static Item bronze_door_item;
	public static Item amethyst_door_item;
	// Presureplates
	public static Block diamond_pressure_plate;
	public static Block copper_pressure_plate;
	public static Block tin_pressure_plate;
	public static Block bronze_pressure_plate;
	public static Block amethyst_pressure_plate;
	public static Block jade_pressure_plate;
	public static Block emerald_pressure_plate;
	public static Block quartz_pressure_plate;
	// Bars
	public static Block stone_bars;
	public static Block gold_bars;
	public static Block diamond_bars;
	public static Block copper_bars;
	public static Block tin_bars;
	public static Block bronze_bars;
	public static Block amethyst_bars;
	public static Block jade_bars;
	public static Block emerald_bars;
	public static Block quartz_bars;
	// Trap doors
	public static Block stone_trapdoor;
	public static Block gold_trapdoor;
	public static Block diamond_trapdoor;
	public static Block copper_trapdoor;
	public static Block tin_trapdoor;
	public static Block bronze_trapdoor;
	public static Block amethyst_trapdoor;
	public static Block jade_trapdoor;
	public static Block emerald_trapdoor;
	public static Block quartz_trapdoor;
	// Buttons
	public static Block iron_button;
	public static Block gold_button;
	public static Block diamond_button;
	public static Block copper_button;
	public static Block tin_button;
	public static Block bronze_button;
	public static Block amethyst_button;
	public static Block jade_button;
	public static Block emerald_button;
	public static Block quartz_button;
	// Fence gates
	public static Block nether_bricks_fence_gate;
	public static Block dark_nether_bricks_fence_gate;
	// Colour blocks
	public static Block colour_block_white;
	public static Block colour_block_light_gray;
	public static Block colour_block_gray;
	public static Block colour_block_black;
	public static Block colour_block_light_blue;
	public static Block colour_block_cyan;
	public static Block colour_block_blue;
	public static Block colour_block_light_green;
	public static Block colour_block_green;
	public static Block colour_block_yellow;
	public static Block colour_block_orange;
	public static Block colour_block_brown;
	public static Block colour_block_magenta;
	public static Block colour_block_purple;
	public static Block colour_block_red;
	public static Block colour_block_pink;
	public static Block colour_changing_block;
	public static Block glowing_colour_block_white;
	public static Block glowing_colour_block_light_gray;
	public static Block glowing_colour_block_gray;
	public static Block glowing_colour_block_black;
	public static Block glowing_colour_block_light_blue;
	public static Block glowing_colour_block_cyan;
	public static Block glowing_colour_block_blue;
	public static Block glowing_colour_block_light_green;
	public static Block glowing_colour_block_green;
	public static Block glowing_colour_block_yellow;
	public static Block glowing_colour_block_orange;
	public static Block glowing_colour_block_brown;
	public static Block glowing_colour_block_magenta;
	public static Block glowing_colour_block_purple;
	public static Block glowing_colour_block_red;
	public static Block glowing_colour_block_pink;
	public static Block glowing_colour_changing_block;
	// Coloured stone bricks
	public static Block coloured_stone_bricks_white;
	public static Block coloured_stone_bricks_light_gray;
	public static Block coloured_stone_bricks_gray;
	public static Block coloured_stone_bricks_black;
	public static Block coloured_stone_bricks_light_blue;
	public static Block coloured_stone_bricks_cyan;
	public static Block coloured_stone_bricks_blue;
	public static Block coloured_stone_bricks_light_green;
	public static Block coloured_stone_bricks_green;
	public static Block coloured_stone_bricks_yellow;
	public static Block coloured_stone_bricks_orange;
	public static Block coloured_stone_bricks_brown;
	public static Block coloured_stone_bricks_magenta;
	public static Block coloured_stone_bricks_purple;
	public static Block coloured_stone_bricks_red;
	public static Block coloured_stone_bricks_pink;
	public static Block colour_changing_stone_bricks;
	public static Block glowing_coloured_stone_bricks_white;
	public static Block glowing_coloured_stone_bricks_light_gray;
	public static Block glowing_coloured_stone_bricks_gray;
	public static Block glowing_coloured_stone_bricks_black;
	public static Block glowing_coloured_stone_bricks_light_blue;
	public static Block glowing_coloured_stone_bricks_cyan;
	public static Block glowing_coloured_stone_bricks_blue;
	public static Block glowing_coloured_stone_bricks_light_green;
	public static Block glowing_coloured_stone_bricks_green;
	public static Block glowing_coloured_stone_bricks_yellow;
	public static Block glowing_coloured_stone_bricks_orange;
	public static Block glowing_coloured_stone_bricks_brown;
	public static Block glowing_coloured_stone_bricks_magenta;
	public static Block glowing_coloured_stone_bricks_purple;
	public static Block glowing_coloured_stone_bricks_red;
	public static Block glowing_coloured_stone_bricks_pink;
	public static Block glowing_colour_changing_stone_bricks;
	// Coloured stone
	public static Block coloured_stone_white;
	public static Block coloured_stone_light_gray;
	public static Block coloured_stone_gray;
	public static Block coloured_stone_black;
	public static Block coloured_stone_light_blue;
	public static Block coloured_stone_cyan;
	public static Block coloured_stone_blue;
	public static Block coloured_stone_light_green;
	public static Block coloured_stone_green;
	public static Block coloured_stone_yellow;
	public static Block coloured_stone_orange;
	public static Block coloured_stone_brown;
	public static Block coloured_stone_magenta;
	public static Block coloured_stone_purple;
	public static Block coloured_stone_red;
	public static Block coloured_stone_pink;
	public static Block colour_changing_stone;
	public static Block glowing_coloured_stone_white;
	public static Block glowing_coloured_stone_light_gray;
	public static Block glowing_coloured_stone_gray;
	public static Block glowing_coloured_stone_black;
	public static Block glowing_coloured_stone_light_blue;
	public static Block glowing_coloured_stone_cyan;
	public static Block glowing_coloured_stone_blue;
	public static Block glowing_coloured_stone_light_green;
	public static Block glowing_coloured_stone_green;
	public static Block glowing_coloured_stone_yellow;
	public static Block glowing_coloured_stone_orange;
	public static Block glowing_coloured_stone_brown;
	public static Block glowing_coloured_stone_magenta;
	public static Block glowing_coloured_stone_purple;
	public static Block glowing_coloured_stone_red;
	public static Block glowing_coloured_stone_pink;
	public static Block glowing_colour_changing_stone;
	// Coloured cobblestone
	public static Block coloured_cobblestone_white;
	public static Block coloured_cobblestone_light_gray;
	public static Block coloured_cobblestone_gray;
	public static Block coloured_cobblestone_black;
	public static Block coloured_cobblestone_light_blue;
	public static Block coloured_cobblestone_cyan;
	public static Block coloured_cobblestone_blue;
	public static Block coloured_cobblestone_light_green;
	public static Block coloured_cobblestone_green;
	public static Block coloured_cobblestone_yellow;
	public static Block coloured_cobblestone_orange;
	public static Block coloured_cobblestone_brown;
	public static Block coloured_cobblestone_magenta;
	public static Block coloured_cobblestone_purple;
	public static Block coloured_cobblestone_red;
	public static Block coloured_cobblestone_pink;
	public static Block colour_changing_cobblestone;
	public static Block glowing_coloured_cobblestone_white;
	public static Block glowing_coloured_cobblestone_light_gray;
	public static Block glowing_coloured_cobblestone_gray;
	public static Block glowing_coloured_cobblestone_black;
	public static Block glowing_coloured_cobblestone_light_blue;
	public static Block glowing_coloured_cobblestone_cyan;
	public static Block glowing_coloured_cobblestone_blue;
	public static Block glowing_coloured_cobblestone_light_green;
	public static Block glowing_coloured_cobblestone_green;
	public static Block glowing_coloured_cobblestone_yellow;
	public static Block glowing_coloured_cobblestone_orange;
	public static Block glowing_coloured_cobblestone_brown;
	public static Block glowing_coloured_cobblestone_magenta;
	public static Block glowing_coloured_cobblestone_purple;
	public static Block glowing_coloured_cobblestone_red;
	public static Block glowing_coloured_cobblestone_pink;
	public static Block glowing_colour_changing_cobblestone;
	// Seamless blocks
	public static Block seamless_stone_slab;
	public static Block seamless_oak_log;
	public static Block seamless_birch_log;
	public static Block seamless_spruce_log;
	public static Block seamless_jungle_log;
	public static Block seamless_acacia_log;
	public static Block seamless_dark_oak_log;
	public static Block seamless_smooth_sandstone;
	public static Block seamless_smooth_red_sandstone;
	// Map making
	public static Block invisible_pressure_plate;
	public static Block glowing_barrier;
	public static Block glowing_air;
	public static Block block_of_death;
	// Machines
	public static Block crusher;
	// Flowers
	public static BlockBush yellow_tulip;
	public static BlockBush blue_tulip;
	public static BlockBush black_tulip;
	public static BlockBush green_tulip;
	public static BlockBush purple_tulip;
	// Misc blocks
	public static Block null_block;
	public static Block scaffolding_block;
	public static Block colour_changing_wool;
	public static Block colour_changing_clay;
	public static Block colour_changing_glass;
	// Stone blocks
	public static Block basalt;
	public static Block basalt_bricks;
	public static Block polished_basalt;
	public static Block polished_stone;
	public static Block granite_bricks;
	public static Block andesite_bricks;
	public static Block diorite_bricks;
	public static Block sandy_bricks;
	public static Block sandy_stone_bricks;
	// Nether blocks
	public static Block dark_nether_bricks;
	// Patterns
	public static Item wooden_pattern;
	public static Item wooden_pattern_bars;
	public static Item wooden_pattern_trapdoor;
	public static Item wooden_pattern_button;
	public static Item wooden_pattern_pressure_plate;
	public static Item wooden_pattern_wall;
	public static Item wooden_pattern_fence;
	public static Item wooden_pattern_fence_gate;
	public static Item wooden_pattern_stairs;

	public static void createBlocksAndItems() {
		// Damage sources
		death_block = new DamageSource("deathBlock").setDamageBypassesArmor().setDamageIsAbsolute();
		// Create blocks
		// Mineral ores
		amethyst_ore = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 3, MapColor.STONE)
				.setUnlocalizedName("amethyst_ore").setCreativeTab(creativeTabWorld).setHardness(5.5F)
				.setResistance(30F);
		jade_ore = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 3, MapColor.STONE)
				.setUnlocalizedName("jade_ore").setCreativeTab(creativeTabWorld).setHardness(5.5F).setResistance(30F);
		copper_ore = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.STONE)
				.setUnlocalizedName("copper_ore").setCreativeTab(creativeTabWorld).setHardness(4.5F).setResistance(25F);
		tin_ore = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.STONE)
				.setUnlocalizedName("tin_ore").setCreativeTab(creativeTabWorld).setHardness(4.5F).setResistance(25F);
		// Mineral blocks
		amethyst_block = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 3, MapColor.PURPLE)
				.setUnlocalizedName("amethyst_block").setCreativeTab(creativeTabBuilding).setHardness(6F)
				.setResistance(35F);
		jade_block = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 3, MapColor.EMERALD)
				.setUnlocalizedName("jade_block").setCreativeTab(creativeTabBuilding).setHardness(6F)
				.setResistance(35F);
		copper_block = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.RED)
				.setUnlocalizedName("copper_block").setCreativeTab(creativeTabBuilding).setHardness(5F)
				.setResistance(30F);
		tin_block = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.IRON)
				.setUnlocalizedName("tin_block").setCreativeTab(creativeTabBuilding).setHardness(5F).setResistance(30F);
		bronze_block = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 2, MapColor.RED)
				.setUnlocalizedName("bronze_block").setCreativeTab(creativeTabBuilding).setHardness(5F)
				.setResistance(30F);
		// Minerals
		amethyst = new Item().setUnlocalizedName("amethyst").setCreativeTab(creativeTab);
		jade = new Item().setUnlocalizedName("jade").setCreativeTab(creativeTab);
		copper_ingot = new Item().setUnlocalizedName("copper_ingot").setCreativeTab(creativeTab);
		tin_ingot = new Item().setUnlocalizedName("tin_ingot").setCreativeTab(creativeTab);
		bronze_ingot = new Item().setUnlocalizedName("bronze_ingot").setCreativeTab(creativeTab);
		// Tools
		stone_shears = new Shears(0, 132, Item.getItemFromBlock(Blocks.STONE)).setUnlocalizedName("stone_shears")
				.setCreativeTab(creativeTabTools);
		gold_shears = new Shears(1, 275, Items.GOLD_INGOT).setUnlocalizedName("gold_shears")
				.setCreativeTab(creativeTabTools);
		diamond_shears = new Shears(2, 1562, Items.DIAMOND).setUnlocalizedName("diamond_shears")
				.setCreativeTab(creativeTabTools);
		diamond_multitool = new Multitool(ToolMaterial.DIAMOND, Items.DIAMOND).setUnlocalizedName("diamond_multitool")
				.setCreativeTab(creativeTabTools);
		op_multitool = new Multitool(opTool, ModElements.amethyst).setUnlocalizedName("op_multitool")
				.setCreativeTab(creativeTabTools);
		amethyst_pickaxe = new Pickaxe(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_pickaxe")
				.setCreativeTab(creativeTabTools);
		amethyst_axe = new Axe(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_axe")
				.setCreativeTab(creativeTabTools);
		amethyst_shovel = new Shovel(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_shovel")
				.setCreativeTab(creativeTabTools);
		amethyst_hoe = new Hoe(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_hoe")
				.setCreativeTab(creativeTabTools);
		amethyst_multitool = new Multitool(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_multitool")
				.setCreativeTab(creativeTabTools);
		amethyst_shears = new Shears(3, 2000, ModElements.amethyst).setUnlocalizedName("amethyst_shears")
				.setCreativeTab(creativeTabTools);
		jade_pickaxe = new Pickaxe(jadeTool, ModElements.jade).setUnlocalizedName("jade_pickaxe")
				.setCreativeTab(creativeTabTools);
		jade_axe = new Axe(jadeTool, ModElements.jade).setUnlocalizedName("jade_axe").setCreativeTab(creativeTabTools);
		jade_shovel = new Shovel(jadeTool, ModElements.jade).setUnlocalizedName("jade_shovel")
				.setCreativeTab(creativeTabTools);
		jade_hoe = new Hoe(jadeTool, ModElements.jade).setUnlocalizedName("jade_hoe").setCreativeTab(creativeTabTools);
		jade_multitool = new Multitool(jadeTool, ModElements.jade).setUnlocalizedName("jade_multitool")
				.setCreativeTab(creativeTabTools);
		jade_shears = new Shears(3, 2000, ModElements.jade).setUnlocalizedName("jade_shears")
				.setCreativeTab(creativeTabTools);
		copper_pickaxe = new Pickaxe(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_pickaxe")
				.setCreativeTab(creativeTabTools);
		copper_axe = new Axe(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_axe")
				.setCreativeTab(creativeTabTools);
		copper_shovel = new Shovel(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_shovel")
				.setCreativeTab(creativeTabTools);
		copper_hoe = new Hoe(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_hoe")
				.setCreativeTab(creativeTabTools);
		copper_multitool = new Multitool(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_multitool")
				.setCreativeTab(creativeTabTools);
		copper_shears = new Shears(1, 170, ModElements.copper_ingot).setUnlocalizedName("copper_shears")
				.setCreativeTab(creativeTabTools);
		bronze_pickaxe = new Pickaxe(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_pickaxe")
				.setCreativeTab(creativeTabTools);
		bronze_axe = new Axe(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_axe")
				.setCreativeTab(creativeTabTools);
		bronze_shovel = new Shovel(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_shovel")
				.setCreativeTab(creativeTabTools);
		bronze_hoe = new Hoe(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_hoe")
				.setCreativeTab(creativeTabTools);
		bronze_multitool = new Multitool(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_multitool")
				.setCreativeTab(creativeTabTools);
		bronze_shears = new Shears(1, 250, ModElements.bronze_ingot).setUnlocalizedName("bronze_shears")
				.setCreativeTab(creativeTabTools);
		// Weapons
		stone_bow = new Bow(132, Item.getItemFromBlock(Blocks.STONE)).setUnlocalizedName("stone_bow")
				.setCreativeTab(creativeTabTools);
		iron_bow = new Bow(238, Items.IRON_INGOT).setUnlocalizedName("iron_bow").setCreativeTab(creativeTabTools);
		gold_bow = new Bow(275, Items.GOLD_INGOT).setUnlocalizedName("gold_bow").setCreativeTab(creativeTabTools);
		diamond_bow = new Bow(1562, Items.DIAMOND).setUnlocalizedName("diamond_bow").setCreativeTab(creativeTabTools);
		jade_sword = new Sword(jadeTool, ModElements.jade).setUnlocalizedName("jade_sword")
				.setCreativeTab(creativeTabTools);
		jade_bow = new Bow(2000, ModElements.jade).setUnlocalizedName("jade_bow").setCreativeTab(creativeTabTools);
		amethyst_sword = new Sword(amethystTool, ModElements.amethyst).setUnlocalizedName("amethyst_sword")
				.setCreativeTab(creativeTabTools);
		amethyst_bow = new Bow(2000, ModElements.amethyst).setUnlocalizedName("amethyst_bow")
				.setCreativeTab(creativeTabTools);
		copper_sword = new Sword(copperTool, ModElements.copper_ingot).setUnlocalizedName("copper_sword")
				.setCreativeTab(creativeTabTools);
		copper_bow = new Bow(170, ModElements.copper_ingot).setUnlocalizedName("copper_bow")
				.setCreativeTab(creativeTabTools);
		bronze_sword = new Sword(bronzeTool, ModElements.bronze_ingot).setUnlocalizedName("bronze_sword")
				.setCreativeTab(creativeTabTools);
		bronze_bow = new Bow(250, ModElements.bronze_ingot).setUnlocalizedName("bronze_bow")
				.setCreativeTab(creativeTabTools);
		op_bow = new Bow(0, ModElements.amethyst).setUnlocalizedName("op_bow").setCreativeTab(creativeTabTools);
		// Shields
		stone_shield = new Shield(132, "stone_shield", creativeTabTools).setUnlocalizedName("stone_shield");
		iron_shield = new Shield(238, "iron_shield", creativeTabTools).setUnlocalizedName("iron_shield");
		gold_shield = new Shield(275, "gold_shield", creativeTabTools).setUnlocalizedName("gold_shield");
		diamond_shield = new Shield(1562, "diamond_shield", creativeTabTools).setUnlocalizedName("diamond_shield");
		copper_shield = new Shield(170, "copper_shield", creativeTabTools).setUnlocalizedName("copper_shield");
		bronze_shield = new Shield(250, "bronze_shield", creativeTabTools).setUnlocalizedName("bronze_shield");
		jade_shield = new Shield(2000, "jade_shield", creativeTabTools).setUnlocalizedName("jade_shield");
		amethyst_shield = new Shield(2000, "amethyst_shield", creativeTabTools).setUnlocalizedName("amethyst_shield");
		// Armour
		amethyst_helmet = new Armour(amethystArmour, 1, EntityEquipmentSlot.HEAD, ModElements.amethyst)
				.setUnlocalizedName("amethyst_helmet").setCreativeTab(creativeTabTools);
		amethyst_chestplate = new Armour(amethystArmour, 1, EntityEquipmentSlot.CHEST, ModElements.amethyst)
				.setUnlocalizedName("amethyst_chestplate").setCreativeTab(creativeTabTools);
		amethyst_leggings = new Armour(amethystArmour, 2, EntityEquipmentSlot.LEGS, ModElements.amethyst)
				.setUnlocalizedName("amethyst_leggings").setCreativeTab(creativeTabTools);
		amethyst_boots = new Armour(amethystArmour, 1, EntityEquipmentSlot.FEET, ModElements.amethyst)
				.setUnlocalizedName("amethyst_boots").setCreativeTab(creativeTabTools);
		jade_helmet = new Armour(jadeArmour, 1, EntityEquipmentSlot.HEAD, ModElements.jade)
				.setUnlocalizedName("jade_helmet").setCreativeTab(creativeTabTools);
		jade_chestplate = new Armour(jadeArmour, 1, EntityEquipmentSlot.CHEST, ModElements.jade)
				.setUnlocalizedName("jade_chestplate").setCreativeTab(creativeTabTools);
		jade_leggings = new Armour(jadeArmour, 2, EntityEquipmentSlot.LEGS, ModElements.jade)
				.setUnlocalizedName("jade_leggings").setCreativeTab(creativeTabTools);
		jade_boots = new Armour(jadeArmour, 1, EntityEquipmentSlot.FEET, ModElements.jade)
				.setUnlocalizedName("jade_boots").setCreativeTab(creativeTabTools);
		copper_helmet = new Armour(copperArmour, 1, EntityEquipmentSlot.HEAD, ModElements.copper_ingot)
				.setUnlocalizedName("copper_helmet").setCreativeTab(creativeTabTools);
		copper_chestplate = new Armour(copperArmour, 1, EntityEquipmentSlot.CHEST, ModElements.copper_ingot)
				.setUnlocalizedName("copper_chestplate").setCreativeTab(creativeTabTools);
		copper_leggings = new Armour(copperArmour, 2, EntityEquipmentSlot.LEGS, ModElements.copper_ingot)
				.setUnlocalizedName("copper_leggings").setCreativeTab(creativeTabTools);
		copper_boots = new Armour(copperArmour, 1, EntityEquipmentSlot.FEET, ModElements.copper_ingot)
				.setUnlocalizedName("copper_boots").setCreativeTab(creativeTabTools);
		bronze_helmet = new Armour(bronzeArmour, 1, EntityEquipmentSlot.HEAD, ModElements.bronze_ingot)
				.setUnlocalizedName("bronze_helmet").setCreativeTab(creativeTabTools);
		bronze_chestplate = new Armour(bronzeArmour, 1, EntityEquipmentSlot.CHEST, ModElements.bronze_ingot)
				.setUnlocalizedName("bronze_chestplate").setCreativeTab(creativeTabTools);
		bronze_leggings = new Armour(bronzeArmour, 2, EntityEquipmentSlot.LEGS, ModElements.bronze_ingot)
				.setUnlocalizedName("bronze_leggings").setCreativeTab(creativeTabTools);
		bronze_boots = new Armour(bronzeArmour, 1, EntityEquipmentSlot.FEET, ModElements.bronze_ingot)
				.setUnlocalizedName("bronze_boots").setCreativeTab(creativeTabTools);
		// Chests
		iron_chest = new ModIronChest(Material.IRON).setUnlocalizedName("iron_chest")
				.setCreativeTab(creativeTabWorkInProgress);
		// gold_chest = new
		// ModIronChest(Material.iron).setUnlocalizedName("gold_chest")
		// .setCreativeTab(creativeTab);
		// Items.DIAMOND_chest = new
		// ModIronChest(Material.iron).setUnlocalizedName("Items.DIAMOND_chest")
		// .setCreativeTab(creativeTab);
		// amethyst_chest = new
		// ModIronChest(Material.iron).setUnlocalizedName("amethyst_chest")
		// .setCreativeTab(creativeTab);
		// Doors
		copper_door = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.RED)
				.setUnlocalizedName("copper_door").setHardness(5F).setResistance(30F);
		tin_door = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 1, MapColor.IRON)
				.setUnlocalizedName("tin_door").setHardness(5F).setResistance(30F);
		bronze_door = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 2, MapColor.RED)
				.setUnlocalizedName("bronze_door").setHardness(5F).setResistance(30F);
		amethyst_door = new ModBlock(Material.ROCK, SoundType.METAL, "pickaxe", 3, MapColor.PURPLE)
				.setUnlocalizedName("amethyst_door").setHardness(6F).setResistance(35F);
		copper_door_item = new Item().setUnlocalizedName("copper_door_item").setCreativeTab(creativeTabBuilding);
		tin_door_item = new Item().setUnlocalizedName("tin_door_item").setCreativeTab(creativeTabBuilding);
		bronze_door_item = new Item().setUnlocalizedName("bronze_door_item").setCreativeTab(creativeTabBuilding);
		amethyst_door_item = new Item().setUnlocalizedName("amethyst_door_item").setCreativeTab(creativeTabBuilding);
		// Pressure plates
		diamond_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("diamond_pressure_plate").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		copper_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 1)
				.setUnlocalizedName("copper_pressure_plate").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		tin_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 1)
				.setUnlocalizedName("tin_pressure_plate").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		bronze_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("bronze_pressure_plate").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		jade_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 3)
				.setUnlocalizedName("jade_pressure_plate").setHardness(6F).setResistance(35F)
				.setCreativeTab(creativeTabBuilding);
		amethyst_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 3)
				.setUnlocalizedName("amethyst_pressure_plate").setHardness(6F).setResistance(35F)
				.setCreativeTab(creativeTabBuilding);
		emerald_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("emerald_pressure_plate").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		quartz_pressure_plate = new ModPresureplate(Material.ROCK, SoundType.METAL, "pickaxe", 0)
				.setUnlocalizedName("quartz_pressure_plate").setHardness(0.8F).setResistance(4F)
				.setCreativeTab(creativeTabBuilding);
		// Bars
		stone_bars = new ModBars(Material.ROCK, SoundType.STONE, "pickaxe", 0, true).setUnlocalizedName("stone_bars")
				.setHardness(1.5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		gold_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 1, true).setUnlocalizedName("gold_bars")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		diamond_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 2, true)
				.setUnlocalizedName("diamond_bars").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		copper_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 1, true).setUnlocalizedName("copper_bars")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		tin_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 1, true).setUnlocalizedName("tin_bars")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		bronze_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 2, true).setUnlocalizedName("bronze_bars")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		jade_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 3, true).setUnlocalizedName("jade_bars")
				.setHardness(6F).setResistance(35F).setCreativeTab(creativeTabBuilding);
		amethyst_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 3, true)
				.setUnlocalizedName("amethyst_bars").setHardness(6F).setResistance(35F)
				.setCreativeTab(creativeTabBuilding);
		emerald_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 2, true)
				.setUnlocalizedName("emerald_bars").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		quartz_bars = new ModBars(Material.ROCK, SoundType.METAL, "pickaxe", 0, true).setUnlocalizedName("quartz_bars")
				.setHardness(0.8F).setResistance(4F).setCreativeTab(creativeTabBuilding);
		// Trap doors
		stone_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.STONE, "pickaxe", 0)
				.setUnlocalizedName("stone_trapdoor").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		gold_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 1)
				.setUnlocalizedName("gold_trapdoor").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		diamond_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("diamond_trapdoor").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		copper_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 1)
				.setUnlocalizedName("copper_trapdoor").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		tin_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 1).setUnlocalizedName("tin_trapdoor")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		bronze_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("bronze_trapdoor").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		jade_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 3)
				.setUnlocalizedName("jade_trapdoor").setHardness(6F).setResistance(35F)
				.setCreativeTab(creativeTabBuilding);
		amethyst_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 3)
				.setUnlocalizedName("amethyst_trapdoor").setHardness(6F).setResistance(35F)
				.setCreativeTab(creativeTabBuilding);
		emerald_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 2)
				.setUnlocalizedName("emerald_trapdoor").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		quartz_trapdoor = new ModTrapDoor(Material.ROCK, SoundType.METAL, "pickaxe", 0)
				.setUnlocalizedName("quartz_trapdoor").setHardness(0.8F).setResistance(4F)
				.setCreativeTab(creativeTabBuilding);
		// Buttons
		iron_button = new ModButton(false, SoundType.METAL, "pickaxe", 1).setUnlocalizedName("iron_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		gold_button = new ModButton(false, SoundType.METAL, "pickaxe", 1).setUnlocalizedName("gold_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		diamond_button = new ModButton(false, SoundType.METAL, "pickaxe", 2).setUnlocalizedName("diamond_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		copper_button = new ModButton(false, SoundType.METAL, "pickaxe", 1).setUnlocalizedName("copper_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		tin_button = new ModButton(false, SoundType.METAL, "pickaxe", 1).setUnlocalizedName("tin_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		bronze_button = new ModButton(false, SoundType.METAL, "pickaxe", 2).setUnlocalizedName("bronze_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		jade_button = new ModButton(false, SoundType.METAL, "pickaxe", 3).setUnlocalizedName("jade_button")
				.setHardness(6F).setResistance(35F).setCreativeTab(creativeTabBuilding);
		amethyst_button = new ModButton(false, SoundType.METAL, "pickaxe", 3).setUnlocalizedName("amethyst_button")
				.setHardness(6F).setResistance(35F).setCreativeTab(creativeTabBuilding);
		emerald_button = new ModButton(false, SoundType.METAL, "pickaxe", 2).setUnlocalizedName("emerald_button")
				.setHardness(5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		quartz_button = new ModButton(false, SoundType.METAL, "pickaxe", 0).setUnlocalizedName("quartz_button")
				.setHardness(0.8F).setResistance(4F).setCreativeTab(creativeTabBuilding);
		// Colour blocks
		colour_block_white = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.IRON)
				.setUnlocalizedName("colour_block_white").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_light_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.GRAY)
				.setUnlocalizedName("colour_block_light_gray").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.GRAY)
				.setUnlocalizedName("colour_block_gray").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_black = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.BLACK)
				.setUnlocalizedName("colour_block_black").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_light_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.LIGHT_BLUE)
				.setUnlocalizedName("colour_block_light_blue").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_cyan = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.CYAN)
				.setUnlocalizedName("colour_block_cyan").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.BLUE)
				.setUnlocalizedName("colour_block_blue").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_light_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.GREEN)
				.setUnlocalizedName("colour_block_light_green").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.GREEN)
				.setUnlocalizedName("colour_block_green").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_yellow = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.YELLOW)
				.setUnlocalizedName("colour_block_yellow").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_orange = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.RED)
				.setUnlocalizedName("colour_block_orange").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_brown = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.BROWN)
				.setUnlocalizedName("colour_block_brown").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_magenta = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.MAGENTA)
				.setUnlocalizedName("colour_block_magenta").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_purple = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.PURPLE)
				.setUnlocalizedName("colour_block_purple").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_red = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.RED)
				.setUnlocalizedName("colour_block_red").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_block_pink = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.PINK)
				.setUnlocalizedName("colour_block_pink").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_block = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.BLACK)
				.setUnlocalizedName("colour_changing_block").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_white = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.IRON).setUnlocalizedName("glowing_colour_block_white").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_light_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.GRAY).setUnlocalizedName("glowing_colour_block_light_gray").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.GRAY).setUnlocalizedName("glowing_colour_block_gray").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_black = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.BLACK).setUnlocalizedName("glowing_colour_block_black").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_light_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.LIGHT_BLUE).setUnlocalizedName("glowing_colour_block_light_blue").setHardness(5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_colour_block_cyan = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.CYAN).setUnlocalizedName("glowing_colour_block_cyan").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.BLUE).setUnlocalizedName("glowing_colour_block_blue").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_light_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.GREEN).setUnlocalizedName("glowing_colour_block_light_green").setHardness(5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_colour_block_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.GREEN).setUnlocalizedName("glowing_colour_block_green").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_yellow = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.YELLOW).setUnlocalizedName("glowing_colour_block_yellow").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_orange = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.RED).setUnlocalizedName("glowing_colour_block_orange").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_brown = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.BROWN).setUnlocalizedName("glowing_colour_block_brown").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_magenta = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.MAGENTA).setUnlocalizedName("glowing_colour_block_magenta").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_purple = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.PURPLE).setUnlocalizedName("glowing_colour_block_purple").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_red = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2, MapColor.RED)
				.setUnlocalizedName("glowing_colour_block_red").setHardness(5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		glowing_colour_block_pink = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.PINK).setUnlocalizedName("glowing_colour_block_pink").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_changing_block = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 2,
				MapColor.BLACK).setUnlocalizedName("glowing_colour_changing_block").setHardness(5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		// Coloured stone bricks
		coloured_stone_bricks_white = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.IRON)
				.setUnlocalizedName("coloured_stone_bricks_white").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_light_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("coloured_stone_bricks_light_gray").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GRAY)
				.setUnlocalizedName("coloured_stone_bricks_gray").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_black = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("coloured_stone_bricks_black").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_light_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.LIGHT_BLUE).setUnlocalizedName("coloured_stone_bricks_light_blue").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_cyan = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.CYAN)
				.setUnlocalizedName("coloured_stone_bricks_cyan").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLUE)
				.setUnlocalizedName("coloured_stone_bricks_blue").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_light_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("coloured_stone_bricks_light_green").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GREEN)
				.setUnlocalizedName("coloured_stone_bricks_green").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_yellow = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.YELLOW)
				.setUnlocalizedName("coloured_stone_bricks_yellow").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_orange = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_stone_bricks_orange").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_brown = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BROWN)
				.setUnlocalizedName("coloured_stone_bricks_brown").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_magenta = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.MAGENTA).setUnlocalizedName("coloured_stone_bricks_magenta").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_purple = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PURPLE)
				.setUnlocalizedName("coloured_stone_bricks_purple").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_red = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_stone_bricks_red").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_bricks_pink = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PINK)
				.setUnlocalizedName("coloured_stone_bricks_pink").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_stone_bricks = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("colour_changing_stone_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_white = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.IRON).setUnlocalizedName("glowing_coloured_stone_bricks_white").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_light_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.GRAY).setUnlocalizedName("glowing_coloured_stone_bricks_light_gray").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("glowing_coloured_stone_bricks_gray").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_black = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_coloured_stone_bricks_black").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_light_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.LIGHT_BLUE).setUnlocalizedName("glowing_coloured_stone_bricks_light_blue").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_cyan = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.CYAN).setUnlocalizedName("glowing_coloured_stone_bricks_cyan").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLUE).setUnlocalizedName("glowing_coloured_stone_bricks_blue").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_light_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.GREEN).setUnlocalizedName("glowing_coloured_stone_bricks_light_green").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("glowing_coloured_stone_bricks_green").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_yellow = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.YELLOW).setUnlocalizedName("glowing_coloured_stone_bricks_yellow").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_orange = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_stone_bricks_orange").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_brown = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BROWN).setUnlocalizedName("glowing_coloured_stone_bricks_brown").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_magenta = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.MAGENTA).setUnlocalizedName("glowing_coloured_stone_bricks_magenta").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_purple = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PURPLE).setUnlocalizedName("glowing_coloured_stone_bricks_purple").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_red = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_stone_bricks_red").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_bricks_pink = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PINK).setUnlocalizedName("glowing_coloured_stone_bricks_pink").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_colour_changing_stone_bricks = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_colour_changing_stone_bricks").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		// Coloured stone
		coloured_stone_white = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.IRON)
				.setUnlocalizedName("coloured_stone_white").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_light_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GRAY)
				.setUnlocalizedName("coloured_stone_light_gray").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GRAY)
				.setUnlocalizedName("coloured_stone_gray").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_black = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("coloured_stone_black").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_light_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.LIGHT_BLUE).setUnlocalizedName("coloured_stone_light_blue").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_stone_cyan = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.CYAN)
				.setUnlocalizedName("coloured_stone_cyan").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLUE)
				.setUnlocalizedName("coloured_stone_blue").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_light_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GREEN)
				.setUnlocalizedName("coloured_stone_light_green").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GREEN)
				.setUnlocalizedName("coloured_stone_green").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_yellow = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.YELLOW)
				.setUnlocalizedName("coloured_stone_yellow").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_orange = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_stone_orange").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_brown = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BROWN)
				.setUnlocalizedName("coloured_stone_brown").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_magenta = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.MAGENTA)
				.setUnlocalizedName("coloured_stone_magenta").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_purple = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PURPLE)
				.setUnlocalizedName("coloured_stone_purple").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_red = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_stone_red").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_stone_pink = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PINK)
				.setUnlocalizedName("coloured_stone_pink").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_stone = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("colour_changing_stone").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_white = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.IRON).setUnlocalizedName("glowing_coloured_stone_white").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_light_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("glowing_coloured_stone_light_gray").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("glowing_coloured_stone_gray").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_black = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_coloured_stone_black").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_light_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.LIGHT_BLUE).setUnlocalizedName("glowing_coloured_stone_light_blue").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_cyan = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.CYAN).setUnlocalizedName("glowing_coloured_stone_cyan").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLUE).setUnlocalizedName("glowing_coloured_stone_blue").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_light_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("glowing_coloured_stone_light_green").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("glowing_coloured_stone_green").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_yellow = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.YELLOW).setUnlocalizedName("glowing_coloured_stone_yellow").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_orange = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_stone_orange").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_brown = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BROWN).setUnlocalizedName("glowing_coloured_stone_brown").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_magenta = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.MAGENTA).setUnlocalizedName("glowing_coloured_stone_magenta").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_purple = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PURPLE).setUnlocalizedName("glowing_coloured_stone_purple").setHardness(1.5F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_red = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_stone_red").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_stone_pink = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PINK).setUnlocalizedName("glowing_coloured_stone_pink").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_colour_changing_stone = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_colour_changing_stone").setHardness(1.5F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		// Coloured cobblestone
		coloured_cobblestone_white = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.IRON)
				.setUnlocalizedName("coloured_cobblestone_white").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_light_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("coloured_cobblestone_light_gray").setHardness(2F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_gray = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GRAY)
				.setUnlocalizedName("coloured_cobblestone_gray").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_black = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("coloured_cobblestone_black").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_light_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.LIGHT_BLUE).setUnlocalizedName("coloured_cobblestone_light_blue").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_cyan = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.CYAN)
				.setUnlocalizedName("coloured_cobblestone_cyan").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_blue = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLUE)
				.setUnlocalizedName("coloured_cobblestone_blue").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_light_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("coloured_cobblestone_light_green").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_green = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.GREEN)
				.setUnlocalizedName("coloured_cobblestone_green").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_yellow = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.YELLOW)
				.setUnlocalizedName("coloured_cobblestone_yellow").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_orange = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_cobblestone_orange").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_brown = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BROWN)
				.setUnlocalizedName("coloured_cobblestone_brown").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_magenta = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.MAGENTA).setUnlocalizedName("coloured_cobblestone_magenta").setHardness(2F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_purple = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PURPLE)
				.setUnlocalizedName("coloured_cobblestone_purple").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_red = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("coloured_cobblestone_red").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		coloured_cobblestone_pink = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.PINK)
				.setUnlocalizedName("coloured_cobblestone_pink").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_cobblestone = new ModColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("colour_changing_cobblestone").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_white = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.IRON).setUnlocalizedName("glowing_coloured_cobblestone_white").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_light_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.GRAY).setUnlocalizedName("glowing_coloured_cobblestone_light_gray").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_gray = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GRAY).setUnlocalizedName("glowing_coloured_cobblestone_gray").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_black = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_coloured_cobblestone_black").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_light_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.LIGHT_BLUE).setUnlocalizedName("glowing_coloured_cobblestone_light_blue").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_cyan = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.CYAN).setUnlocalizedName("glowing_coloured_cobblestone_cyan").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_blue = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLUE).setUnlocalizedName("glowing_coloured_cobblestone_blue").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_light_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe",
				0, MapColor.GREEN).setUnlocalizedName("glowing_coloured_cobblestone_light_green").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_green = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.GREEN).setUnlocalizedName("glowing_coloured_cobblestone_green").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_yellow = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.YELLOW).setUnlocalizedName("glowing_coloured_cobblestone_yellow").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_orange = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_cobblestone_orange").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_brown = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BROWN).setUnlocalizedName("glowing_coloured_cobblestone_brown").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_magenta = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.MAGENTA).setUnlocalizedName("glowing_coloured_cobblestone_magenta").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_purple = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PURPLE).setUnlocalizedName("glowing_coloured_cobblestone_purple").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_red = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.RED).setUnlocalizedName("glowing_coloured_cobblestone_red").setHardness(2F).setResistance(30F)
						.setCreativeTab(creativeTabBuilding);
		glowing_coloured_cobblestone_pink = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.PINK).setUnlocalizedName("glowing_coloured_cobblestone_pink").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		glowing_colour_changing_cobblestone = new ModGlowingColourBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0,
				MapColor.BLACK).setUnlocalizedName("glowing_colour_changing_cobblestone").setHardness(2F)
						.setResistance(30F).setCreativeTab(creativeTabBuilding);
		// Seamless blocks
		seamless_stone_slab = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.STONE)
				.setUnlocalizedName("seamless_stone_slab").setCreativeTab(creativeTabBuilding).setResistance(30)
				.setHardness(2);
		seamless_oak_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_oak_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_birch_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_birch_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_spruce_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_spruce_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_jungle_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_jungle_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_acacia_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_acacia_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_dark_oak_log = new ModBlock(Material.WOOD, SoundType.WOOD, "axe", 0, MapColor.WOOD)
				.setUnlocalizedName("seamless_dark_oak_log").setCreativeTab(creativeTabBuilding).setResistance(10)
				.setHardness(2);
		seamless_smooth_sandstone = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.SAND)
				.setUnlocalizedName("seamless_smooth_sandstone").setCreativeTab(creativeTabBuilding).setResistance(4)
				.setHardness(0.8F);
		seamless_smooth_red_sandstone = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("seamless_smooth_red_sandstone").setCreativeTab(creativeTabBuilding)
				.setResistance(4).setHardness(0.8F);
		// Map making blocks
		invisible_pressure_plate = new ModPresureplate(Material.BARRIER, true, true)
				.setCreativeTab(creativeTabMapMaking).setResistance(18000000)
				.setUnlocalizedName("invisible_pressure_plate");
		glowing_barrier = new ModBlock(Material.BARRIER, SoundType.GLASS, "pickaxe", 0, true, 1, true)
				.setResistance(18000000).setCreativeTab(creativeTabMapMaking).setUnlocalizedName("glowing_barrier");
		glowing_air = new ModGlowingAir(Material.BARRIER).setResistance(18000000).setCreativeTab(creativeTabMapMaking)
				.setUnlocalizedName("glowing_air");
		block_of_death = new ModDeathBlock(Material.ROCK).setCreativeTab(creativeTabMapMaking)
				.setUnlocalizedName("block_of_death").setResistance(10).setHardness(5);
		// Machines
		crusher = new ModCrusher().setUnlocalizedName("crusher").setCreativeTab(creativeTabWorkInProgress)
				.setResistance(30).setHardness(5);
		// Flowers
		yellow_tulip = (BlockBush) new ModFlower().setUnlocalizedName("yellow_tulip").setCreativeTab(creativeTabWorld);
		blue_tulip = (BlockBush) new ModFlower().setUnlocalizedName("blue_tulip").setCreativeTab(creativeTabWorld);
		black_tulip = (BlockBush) new ModFlower().setUnlocalizedName("black_tulip").setCreativeTab(creativeTabWorld);
		green_tulip = (BlockBush) new ModFlower().setUnlocalizedName("green_tulip").setCreativeTab(creativeTabWorld);
		purple_tulip = (BlockBush) new ModFlower().setUnlocalizedName("purple_tulip").setCreativeTab(creativeTabWorld);
		// Misc blocks
		null_block = new Block(Material.BARRIER).setBlockUnbreakable().setUnlocalizedName("null_block")
				.setResistance(1000000F).setCreativeTab(creativeTabBuilding);
		scaffolding_block = new ModBlock(Material.GROUND, SoundType.WOOD, true, MapColor.WOOD)
				.setUnlocalizedName("scaffolding_block").setCreativeTab(creativeTabBuilding);
		colour_changing_wool = new ModColourBlock(Material.CLOTH, SoundType.CLOTH, null, 0, MapColor.CLOTH)
				.setUnlocalizedName("colour_changing_wool").setHardness(0.8F).setResistance(4F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_clay = new ModColourBlock(Material.CLAY, SoundType.STONE, "pickaxe", 0, MapColor.CLAY)
				.setUnlocalizedName("colour_changing_clay").setHardness(1.25F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		colour_changing_glass = new ModColourChangingClass(Material.GLASS, SoundType.GLASS, MapColor.AIR)
				.setUnlocalizedName("colour_changing_glass").setHardness(0.3F).setResistance(1.5F)
				.setCreativeTab(creativeTabBuilding);
		// Stone blocks
		basalt = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK).setUnlocalizedName("basalt")
				.setHardness(1.5F).setResistance(30F).setCreativeTab(creativeTabBuilding);
		basalt_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("basalt_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		polished_basalt = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("polished_basalt").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		polished_stone = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.STONE)
				.setUnlocalizedName("polished_stone").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		granite_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("granite_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		andesite_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.STONE)
				.setUnlocalizedName("andesite_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		diorite_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.IRON)
				.setUnlocalizedName("diorite_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		sandy_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.SAND)
				.setUnlocalizedName("sandy_bricks").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		sandy_stone_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.SAND)
				.setUnlocalizedName("sandy_stone_bricks").setHardness(1.5F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		// Nether bricks
		dark_nether_bricks = new ModBlock(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("dark_nether_bricks").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		// Fence gates
		nether_bricks_fence_gate = new ModFenceGate(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.RED)
				.setUnlocalizedName("nether_bricks_fence_gate").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		dark_nether_bricks_fence_gate = new ModFenceGate(Material.ROCK, SoundType.STONE, "pickaxe", 0, MapColor.BLACK)
				.setUnlocalizedName("dark_nether_bricks_fence_gate").setHardness(2F).setResistance(30F)
				.setCreativeTab(creativeTabBuilding);
		// Patterns
		wooden_pattern = new Item().setUnlocalizedName("wooden_pattern").setCreativeTab(creativeTab);
		wooden_pattern_bars = new Item().setUnlocalizedName("wooden_pattern_bars").setCreativeTab(creativeTab);
		wooden_pattern_button = new Item().setUnlocalizedName("wooden_pattern_button").setCreativeTab(creativeTab);
		wooden_pattern_pressure_plate = new Item().setUnlocalizedName("wooden_pattern_pressure_plate")
				.setCreativeTab(creativeTab);
		wooden_pattern_trapdoor = new Item().setUnlocalizedName("wooden_pattern_trapdoor").setCreativeTab(creativeTab);
		wooden_pattern_wall = new Item().setUnlocalizedName("wooden_pattern_wall").setCreativeTab(creativeTab);
		wooden_pattern_fence = new Item().setUnlocalizedName("wooden_pattern_fence").setCreativeTab(creativeTab);
		wooden_pattern_fence_gate = new Item().setUnlocalizedName("wooden_pattern_fence_gate")
				.setCreativeTab(creativeTab);
		wooden_pattern_stairs = new Item().setUnlocalizedName("wooden_pattern_stairs").setCreativeTab(creativeTab);
	}

	public static void registerItemsAndBlocks() {
		// Register blocks
		// Mineral ores
		Registry.registerBlock(amethyst_ore, amethyst_ore.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_ore, jade_ore.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_ore, copper_ore.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_ore, tin_ore.getUnlocalizedName().substring(5));
		// Mineral blocks
		Registry.registerBlock(amethyst_block, amethyst_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_block, jade_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_block, copper_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_block, tin_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(bronze_block, bronze_block.getUnlocalizedName().substring(5));
		// Minerals
		Registry.registerItem(amethyst, amethyst.getUnlocalizedName().substring(5));
		Registry.registerItem(jade, jade.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_ingot, copper_ingot.getUnlocalizedName().substring(5));
		Registry.registerItem(tin_ingot, tin_ingot.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_ingot, bronze_ingot.getUnlocalizedName().substring(5));
		// Tools
		Registry.registerItem(stone_shears, stone_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(gold_shears, gold_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(diamond_shears, diamond_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(diamond_multitool, diamond_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(op_multitool, op_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_pickaxe, amethyst_pickaxe.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_axe, amethyst_axe.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_shovel, amethyst_shovel.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_hoe, amethyst_hoe.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_multitool, amethyst_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_shears, amethyst_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_pickaxe, jade_pickaxe.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_axe, jade_axe.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_shovel, jade_shovel.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_hoe, jade_hoe.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_multitool, jade_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_shears, jade_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_pickaxe, copper_pickaxe.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_axe, copper_axe.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_shovel, copper_shovel.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_hoe, copper_hoe.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_multitool, copper_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_shears, copper_shears.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_pickaxe, bronze_pickaxe.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_axe, bronze_axe.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_shovel, bronze_shovel.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_hoe, bronze_hoe.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_multitool, bronze_multitool.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_shears, bronze_shears.getUnlocalizedName().substring(5));
		// Shields
		Registry.registerItem(stone_shield, stone_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(iron_shield, iron_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(gold_shield, gold_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(diamond_shield, diamond_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_shield, copper_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_shield, bronze_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_shield, jade_shield.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_shield, amethyst_shield.getUnlocalizedName().substring(5));
		// Weapons
		Registry.registerItem(stone_bow, stone_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(iron_bow, iron_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(gold_bow, gold_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(diamond_bow, diamond_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_sword, jade_sword.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_bow, jade_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_sword, amethyst_sword.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_bow, amethyst_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_sword, copper_sword.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_bow, copper_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_sword, bronze_sword.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_bow, bronze_bow.getUnlocalizedName().substring(5));
		Registry.registerItem(op_bow, op_bow.getUnlocalizedName().substring(5));
		// Armour
		Registry.registerItem(amethyst_helmet, amethyst_helmet.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_chestplate, amethyst_chestplate.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_leggings, amethyst_leggings.getUnlocalizedName().substring(5));
		Registry.registerItem(amethyst_boots, amethyst_boots.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_helmet, jade_helmet.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_chestplate, jade_chestplate.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_leggings, jade_leggings.getUnlocalizedName().substring(5));
		Registry.registerItem(jade_boots, jade_boots.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_helmet, copper_helmet.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_chestplate, copper_chestplate.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_leggings, copper_leggings.getUnlocalizedName().substring(5));
		Registry.registerItem(copper_boots, copper_boots.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_helmet, bronze_helmet.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_chestplate, bronze_chestplate.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_leggings, bronze_leggings.getUnlocalizedName().substring(5));
		Registry.registerItem(bronze_boots, bronze_boots.getUnlocalizedName().substring(5));
		// Chests
		Registry.registerBlock(iron_chest, iron_chest.getUnlocalizedName().substring(5));
		GameRegistry.registerTileEntity(TileEntityIronChest.class, "tile_enity_iron_chest");
		// Registry.registerBlock(gold_chest,
		// gold_chest.getUnlocalizedName().substring(5));
		// Registry.registerBlock(Items.DIAMOND_chest,
		// Items.DIAMOND_chest.getUnlocalizedName().substring(5));
		// Registry.registerBlock(amethyst_chest,
		// amethyst_chest.getUnlocalizedName().substring(5));
		// Presureplates
		Registry.registerBlock(diamond_pressure_plate, diamond_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_pressure_plate, copper_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_pressure_plate, tin_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(bronze_pressure_plate, bronze_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(amethyst_pressure_plate, amethyst_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_pressure_plate, jade_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(emerald_pressure_plate, emerald_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(quartz_pressure_plate, quartz_pressure_plate.getUnlocalizedName().substring(5));
		// Bars
		Registry.registerBlock(stone_bars, stone_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(gold_bars, gold_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(diamond_bars, diamond_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_bars, copper_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_bars, tin_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(bronze_bars, bronze_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(amethyst_bars, amethyst_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_bars, jade_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(emerald_bars, emerald_bars.getUnlocalizedName().substring(5));
		Registry.registerBlock(quartz_bars, quartz_bars.getUnlocalizedName().substring(5));
		// Trap doors
		Registry.registerBlock(stone_trapdoor, stone_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(gold_trapdoor, gold_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(diamond_trapdoor, diamond_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_trapdoor, copper_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_trapdoor, tin_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(bronze_trapdoor, bronze_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(amethyst_trapdoor, amethyst_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_trapdoor, jade_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(emerald_trapdoor, emerald_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerBlock(quartz_trapdoor, quartz_trapdoor.getUnlocalizedName().substring(5));
		// Buttons
		Registry.registerBlock(iron_button, iron_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(gold_button, gold_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(diamond_button, diamond_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(copper_button, copper_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(tin_button, tin_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(bronze_button, bronze_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(amethyst_button, amethyst_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(jade_button, jade_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(emerald_button, emerald_button.getUnlocalizedName().substring(5));
		Registry.registerBlock(quartz_button, quartz_button.getUnlocalizedName().substring(5));
		// Fence gates
		/*
		 * Registry.registerBlock(nether_bricks_fence_gate,
		 * nether_bricks_fence_gate.getUnlocalizedName().substring(5));
		 * Registry.registerBlock(dark_nether_bricks_fence_gate,
		 * dark_nether_bricks_fence_gate.getUnlocalizedName().substring(5));
		 */
		// Colour blocks
		Registry.registerBlock(colour_block_white, colour_block_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_light_gray, colour_block_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_gray, colour_block_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_black, colour_block_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_light_blue, colour_block_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_cyan, colour_block_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_blue, colour_block_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_light_green, colour_block_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_yellow, colour_block_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_orange, colour_block_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_brown, colour_block_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_magenta, colour_block_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_purple, colour_block_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_red, colour_block_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_pink, colour_block_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_block_green, colour_block_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_block, colour_changing_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_white,
				glowing_colour_block_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_light_gray,
				glowing_colour_block_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_gray, glowing_colour_block_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_black,
				glowing_colour_block_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_light_blue,
				glowing_colour_block_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_cyan, glowing_colour_block_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_blue, glowing_colour_block_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_light_green,
				glowing_colour_block_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_yellow,
				glowing_colour_block_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_orange,
				glowing_colour_block_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_brown,
				glowing_colour_block_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_magenta,
				glowing_colour_block_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_purple,
				glowing_colour_block_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_red, glowing_colour_block_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_pink, glowing_colour_block_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_block_green,
				glowing_colour_block_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_changing_block,
				glowing_colour_changing_block.getUnlocalizedName().substring(5));
		// Coloured stone bricks
		Registry.registerBlock(coloured_stone_bricks_white,
				coloured_stone_bricks_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_light_gray,
				coloured_stone_bricks_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_gray,
				coloured_stone_bricks_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_black,
				coloured_stone_bricks_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_light_blue,
				coloured_stone_bricks_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_cyan,
				coloured_stone_bricks_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_blue,
				coloured_stone_bricks_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_light_green,
				coloured_stone_bricks_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_yellow,
				coloured_stone_bricks_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_orange,
				coloured_stone_bricks_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_brown,
				coloured_stone_bricks_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_magenta,
				coloured_stone_bricks_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_purple,
				coloured_stone_bricks_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_red, coloured_stone_bricks_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_pink,
				coloured_stone_bricks_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_bricks_green,
				coloured_stone_bricks_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_stone_bricks,
				colour_changing_stone_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_white,
				glowing_coloured_stone_bricks_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_light_gray,
				glowing_coloured_stone_bricks_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_gray,
				glowing_coloured_stone_bricks_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_black,
				glowing_coloured_stone_bricks_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_light_blue,
				glowing_coloured_stone_bricks_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_cyan,
				glowing_coloured_stone_bricks_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_blue,
				glowing_coloured_stone_bricks_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_light_green,
				glowing_coloured_stone_bricks_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_yellow,
				glowing_coloured_stone_bricks_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_orange,
				glowing_coloured_stone_bricks_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_brown,
				glowing_coloured_stone_bricks_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_magenta,
				glowing_coloured_stone_bricks_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_purple,
				glowing_coloured_stone_bricks_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_red,
				glowing_coloured_stone_bricks_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_pink,
				glowing_coloured_stone_bricks_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_bricks_green,
				glowing_coloured_stone_bricks_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_changing_stone_bricks,
				glowing_colour_changing_stone_bricks.getUnlocalizedName().substring(5));
		// Coloured stone
		Registry.registerBlock(coloured_stone_white, coloured_stone_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_light_gray, coloured_stone_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_gray, coloured_stone_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_black, coloured_stone_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_light_blue, coloured_stone_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_cyan, coloured_stone_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_blue, coloured_stone_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_light_green,
				coloured_stone_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_yellow, coloured_stone_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_orange, coloured_stone_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_brown, coloured_stone_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_magenta, coloured_stone_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_purple, coloured_stone_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_red, coloured_stone_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_pink, coloured_stone_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_stone_green, coloured_stone_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_stone, colour_changing_stone.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_white,
				glowing_coloured_stone_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_light_gray,
				glowing_coloured_stone_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_gray,
				glowing_coloured_stone_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_black,
				glowing_coloured_stone_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_light_blue,
				glowing_coloured_stone_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_cyan,
				glowing_coloured_stone_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_blue,
				glowing_coloured_stone_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_light_green,
				glowing_coloured_stone_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_yellow,
				glowing_coloured_stone_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_orange,
				glowing_coloured_stone_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_brown,
				glowing_coloured_stone_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_magenta,
				glowing_coloured_stone_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_purple,
				glowing_coloured_stone_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_red,
				glowing_coloured_stone_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_pink,
				glowing_coloured_stone_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_stone_green,
				glowing_coloured_stone_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_changing_stone,
				glowing_colour_changing_stone.getUnlocalizedName().substring(5));
		// Coloured cobblestone
		Registry.registerBlock(coloured_cobblestone_white,
				coloured_cobblestone_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_light_gray,
				coloured_cobblestone_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_gray, coloured_cobblestone_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_black,
				coloured_cobblestone_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_light_blue,
				coloured_cobblestone_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_cyan, coloured_cobblestone_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_blue, coloured_cobblestone_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_light_green,
				coloured_cobblestone_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_yellow,
				coloured_cobblestone_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_orange,
				coloured_cobblestone_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_brown,
				coloured_cobblestone_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_magenta,
				coloured_cobblestone_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_purple,
				coloured_cobblestone_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_red, coloured_cobblestone_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_pink, coloured_cobblestone_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(coloured_cobblestone_green,
				coloured_cobblestone_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_cobblestone,
				colour_changing_cobblestone.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_white,
				glowing_coloured_cobblestone_white.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_light_gray,
				glowing_coloured_cobblestone_light_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_gray,
				glowing_coloured_cobblestone_gray.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_black,
				glowing_coloured_cobblestone_black.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_light_blue,
				glowing_coloured_cobblestone_light_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_cyan,
				glowing_coloured_cobblestone_cyan.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_blue,
				glowing_coloured_cobblestone_blue.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_light_green,
				glowing_coloured_cobblestone_light_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_yellow,
				glowing_coloured_cobblestone_yellow.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_orange,
				glowing_coloured_cobblestone_orange.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_brown,
				glowing_coloured_cobblestone_brown.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_magenta,
				glowing_coloured_cobblestone_magenta.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_purple,
				glowing_coloured_cobblestone_purple.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_red,
				glowing_coloured_cobblestone_red.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_pink,
				glowing_coloured_cobblestone_pink.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_coloured_cobblestone_green,
				glowing_coloured_cobblestone_green.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_colour_changing_cobblestone,
				glowing_colour_changing_cobblestone.getUnlocalizedName().substring(5));
		// Seamless blocks
		Registry.registerBlock(seamless_stone_slab, seamless_stone_slab.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_oak_log, seamless_oak_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_birch_log, seamless_birch_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_spruce_log, seamless_spruce_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_jungle_log, seamless_jungle_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_acacia_log, seamless_acacia_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_dark_oak_log, seamless_dark_oak_log.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_smooth_sandstone, seamless_smooth_sandstone.getUnlocalizedName().substring(5));
		Registry.registerBlock(seamless_smooth_red_sandstone,
				seamless_smooth_red_sandstone.getUnlocalizedName().substring(5));
		// Map making blocks
		Registry.registerBlock(invisible_pressure_plate, invisible_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_barrier, glowing_barrier.getUnlocalizedName().substring(5));
		Registry.registerBlock(glowing_air, glowing_air.getUnlocalizedName().substring(5));
		Registry.registerBlock(block_of_death, block_of_death.getUnlocalizedName().substring(5));
		// Machines
		Registry.registerBlock(crusher, crusher.getUnlocalizedName().substring(5));
		// Flowers
		Registry.registerBlock(yellow_tulip, yellow_tulip.getUnlocalizedName().substring(5));
		Registry.registerBlock(blue_tulip, blue_tulip.getUnlocalizedName().substring(5));
		Registry.registerBlock(black_tulip, black_tulip.getUnlocalizedName().substring(5));
		Registry.registerBlock(green_tulip, green_tulip.getUnlocalizedName().substring(5));
		Registry.registerBlock(purple_tulip, purple_tulip.getUnlocalizedName().substring(5));
		// Misc blocks
		Registry.registerBlock(null_block, null_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(scaffolding_block, scaffolding_block.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_wool, colour_changing_wool.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_clay, colour_changing_clay.getUnlocalizedName().substring(5));
		Registry.registerBlock(colour_changing_glass, colour_changing_glass.getUnlocalizedName().substring(5));
		// Stone blocks
		Registry.registerBlock(basalt, basalt.getUnlocalizedName().substring(5));
		Registry.registerBlock(basalt_bricks, basalt_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(polished_basalt, polished_basalt.getUnlocalizedName().substring(5));
		Registry.registerBlock(polished_stone, polished_stone.getUnlocalizedName().substring(5));
		Registry.registerBlock(granite_bricks, granite_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(andesite_bricks, andesite_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(diorite_bricks, diorite_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(sandy_bricks, sandy_bricks.getUnlocalizedName().substring(5));
		Registry.registerBlock(sandy_stone_bricks, sandy_stone_bricks.getUnlocalizedName().substring(5));
		// Nether blocks
		Registry.registerBlock(dark_nether_bricks, dark_nether_bricks.getUnlocalizedName().substring(5));
		// Patterns
		Registry.registerItem(wooden_pattern, wooden_pattern.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_bars, wooden_pattern_bars.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_button, wooden_pattern_button.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_pressure_plate,
				wooden_pattern_pressure_plate.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_trapdoor, wooden_pattern_trapdoor.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_wall, wooden_pattern_wall.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_fence, wooden_pattern_fence.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_fence_gate, wooden_pattern_fence_gate.getUnlocalizedName().substring(5));
		Registry.registerItem(wooden_pattern_stairs, wooden_pattern_stairs.getUnlocalizedName().substring(5));
	}

	public static void registerRenders() {
		// Mineral ores
		registerRenderBlock(amethyst_ore);
		registerRenderBlock(jade_ore);
		registerRenderBlock(copper_ore);
		registerRenderBlock(tin_ore);
		// Mineral blocks
		registerRenderBlock(amethyst_block);
		registerRenderBlock(jade_block);
		registerRenderBlock(copper_block);
		registerRenderBlock(tin_block);
		registerRenderBlock(bronze_block);
		// Minerals
		registerRenderItem(amethyst);
		registerRenderItem(jade);
		registerRenderItem(copper_ingot);
		registerRenderItem(tin_ingot);
		registerRenderItem(bronze_ingot);
		// Tools
		registerRenderItem(stone_shears);
		registerRenderItem(gold_shears);
		registerRenderItem(diamond_shears);
		registerRenderItem(diamond_multitool);
		registerRenderItem(op_multitool);
		registerRenderItem(amethyst_pickaxe);
		registerRenderItem(amethyst_axe);
		registerRenderItem(amethyst_shovel);
		registerRenderItem(amethyst_hoe);
		registerRenderItem(amethyst_multitool);
		registerRenderItem(amethyst_shears);
		registerRenderItem(jade_pickaxe);
		registerRenderItem(jade_axe);
		registerRenderItem(jade_shovel);
		registerRenderItem(jade_hoe);
		registerRenderItem(jade_multitool);
		registerRenderItem(jade_shears);
		registerRenderItem(copper_pickaxe);
		registerRenderItem(copper_axe);
		registerRenderItem(copper_shovel);
		registerRenderItem(copper_hoe);
		registerRenderItem(copper_multitool);
		registerRenderItem(copper_shears);
		registerRenderItem(bronze_pickaxe);
		registerRenderItem(bronze_axe);
		registerRenderItem(bronze_shovel);
		registerRenderItem(bronze_hoe);
		registerRenderItem(bronze_multitool);
		registerRenderItem(bronze_shears);
		// Shields
		registerRenderItem(stone_shield);
		registerRenderItem(iron_shield);
		registerRenderItem(gold_shield);
		registerRenderItem(diamond_shield);
		registerRenderItem(copper_shield);
		registerRenderItem(bronze_shield);
		registerRenderItem(jade_shield);
		registerRenderItem(amethyst_shield);
		// Weapons
		registerRenderItem(stone_bow);
		registerRenderItem(iron_bow);
		registerRenderItem(gold_bow);
		registerRenderItem(diamond_bow);
		registerRenderItem(jade_sword);
		registerRenderItem(jade_bow);
		registerRenderItem(amethyst_sword);
		registerRenderItem(amethyst_bow);
		registerRenderItem(copper_sword);
		registerRenderItem(copper_bow);
		registerRenderItem(bronze_sword);
		registerRenderItem(bronze_bow);
		registerRenderItem(op_bow);
		// Armour
		registerRenderItem(amethyst_helmet);
		registerRenderItem(amethyst_chestplate);
		registerRenderItem(amethyst_leggings);
		registerRenderItem(amethyst_boots);
		registerRenderItem(jade_helmet);
		registerRenderItem(jade_chestplate);
		registerRenderItem(jade_leggings);
		registerRenderItem(jade_boots);
		registerRenderItem(copper_helmet);
		registerRenderItem(copper_chestplate);
		registerRenderItem(copper_leggings);
		registerRenderItem(copper_boots);
		registerRenderItem(bronze_helmet);
		registerRenderItem(bronze_chestplate);
		registerRenderItem(bronze_leggings);
		registerRenderItem(bronze_boots);
		// Chests
		// registerRenderBlock(iron_chest);
		// registerRenderBlock(gold_chest);
		// registerRenderBlock(Items.DIAMOND_chest);
		// registerRenderBlock(amethyst_chest);
		// Doors

		// Presureplates
		registerRenderBlock(diamond_pressure_plate);
		registerRenderBlock(copper_pressure_plate);
		registerRenderBlock(tin_pressure_plate);
		registerRenderBlock(bronze_pressure_plate);
		registerRenderBlock(amethyst_pressure_plate);
		registerRenderBlock(jade_pressure_plate);
		registerRenderBlock(emerald_pressure_plate);
		registerRenderBlock(quartz_pressure_plate);
		// Bars
		registerRenderBlock(stone_bars);
		registerRenderBlock(gold_bars);
		registerRenderBlock(diamond_bars);
		registerRenderBlock(copper_bars);
		registerRenderBlock(tin_bars);
		registerRenderBlock(bronze_bars);
		registerRenderBlock(amethyst_bars);
		registerRenderBlock(jade_bars);
		registerRenderBlock(emerald_bars);
		registerRenderBlock(quartz_bars);
		// Trap doors
		registerRenderBlock(stone_trapdoor);
		registerRenderBlock(gold_trapdoor);
		registerRenderBlock(diamond_trapdoor);
		registerRenderBlock(copper_trapdoor);
		registerRenderBlock(tin_trapdoor);
		registerRenderBlock(bronze_trapdoor);
		registerRenderBlock(amethyst_trapdoor);
		registerRenderBlock(jade_trapdoor);
		registerRenderBlock(emerald_trapdoor);
		registerRenderBlock(quartz_trapdoor);
		// Buttons
		registerRenderBlock(iron_button);
		registerRenderBlock(gold_button);
		registerRenderBlock(diamond_button);
		registerRenderBlock(copper_button);
		registerRenderBlock(tin_button);
		registerRenderBlock(bronze_button);
		registerRenderBlock(amethyst_button);
		registerRenderBlock(jade_button);
		registerRenderBlock(emerald_button);
		registerRenderBlock(quartz_button);
		// Fence gates
		// registerRenderBlock(nether_bricks_fence_gate);
		// registerRenderBlock(dark_nether_bricks_fence_gate);
		// Colour blocks
		registerRenderBlock(colour_block_white);
		registerRenderBlock(colour_block_light_gray);
		registerRenderBlock(colour_block_gray);
		registerRenderBlock(colour_block_black);
		registerRenderBlock(colour_block_light_blue);
		registerRenderBlock(colour_block_cyan);
		registerRenderBlock(colour_block_blue);
		registerRenderBlock(colour_block_light_green);
		registerRenderBlock(colour_block_green);
		registerRenderBlock(colour_block_yellow);
		registerRenderBlock(colour_block_orange);
		registerRenderBlock(colour_block_brown);
		registerRenderBlock(colour_block_magenta);
		registerRenderBlock(colour_block_purple);
		registerRenderBlock(colour_block_red);
		registerRenderBlock(colour_block_pink);
		registerRenderBlock(colour_changing_block);
		registerRenderBlock(glowing_colour_block_white);
		registerRenderBlock(glowing_colour_block_light_gray);
		registerRenderBlock(glowing_colour_block_gray);
		registerRenderBlock(glowing_colour_block_black);
		registerRenderBlock(glowing_colour_block_light_blue);
		registerRenderBlock(glowing_colour_block_cyan);
		registerRenderBlock(glowing_colour_block_blue);
		registerRenderBlock(glowing_colour_block_light_green);
		registerRenderBlock(glowing_colour_block_green);
		registerRenderBlock(glowing_colour_block_yellow);
		registerRenderBlock(glowing_colour_block_orange);
		registerRenderBlock(glowing_colour_block_brown);
		registerRenderBlock(glowing_colour_block_magenta);
		registerRenderBlock(glowing_colour_block_purple);
		registerRenderBlock(glowing_colour_block_red);
		registerRenderBlock(glowing_colour_block_pink);
		registerRenderBlock(glowing_colour_changing_block);
		// Coloured stone bricks
		registerRenderBlock(coloured_stone_bricks_white);
		registerRenderBlock(coloured_stone_bricks_light_gray);
		registerRenderBlock(coloured_stone_bricks_gray);
		registerRenderBlock(coloured_stone_bricks_black);
		registerRenderBlock(coloured_stone_bricks_light_blue);
		registerRenderBlock(coloured_stone_bricks_cyan);
		registerRenderBlock(coloured_stone_bricks_blue);
		registerRenderBlock(coloured_stone_bricks_light_green);
		registerRenderBlock(coloured_stone_bricks_green);
		registerRenderBlock(coloured_stone_bricks_yellow);
		registerRenderBlock(coloured_stone_bricks_orange);
		registerRenderBlock(coloured_stone_bricks_brown);
		registerRenderBlock(coloured_stone_bricks_magenta);
		registerRenderBlock(coloured_stone_bricks_purple);
		registerRenderBlock(coloured_stone_bricks_red);
		registerRenderBlock(coloured_stone_bricks_pink);
		registerRenderBlock(colour_changing_stone_bricks);
		registerRenderBlock(glowing_coloured_stone_bricks_white);
		registerRenderBlock(glowing_coloured_stone_bricks_light_gray);
		registerRenderBlock(glowing_coloured_stone_bricks_gray);
		registerRenderBlock(glowing_coloured_stone_bricks_black);
		registerRenderBlock(glowing_coloured_stone_bricks_light_blue);
		registerRenderBlock(glowing_coloured_stone_bricks_cyan);
		registerRenderBlock(glowing_coloured_stone_bricks_blue);
		registerRenderBlock(glowing_coloured_stone_bricks_light_green);
		registerRenderBlock(glowing_coloured_stone_bricks_green);
		registerRenderBlock(glowing_coloured_stone_bricks_yellow);
		registerRenderBlock(glowing_coloured_stone_bricks_orange);
		registerRenderBlock(glowing_coloured_stone_bricks_brown);
		registerRenderBlock(glowing_coloured_stone_bricks_magenta);
		registerRenderBlock(glowing_coloured_stone_bricks_purple);
		registerRenderBlock(glowing_coloured_stone_bricks_red);
		registerRenderBlock(glowing_coloured_stone_bricks_pink);
		registerRenderBlock(glowing_colour_changing_stone_bricks);
		// Coloured stone
		registerRenderBlock(coloured_stone_white);
		registerRenderBlock(coloured_stone_light_gray);
		registerRenderBlock(coloured_stone_gray);
		registerRenderBlock(coloured_stone_black);
		registerRenderBlock(coloured_stone_light_blue);
		registerRenderBlock(coloured_stone_cyan);
		registerRenderBlock(coloured_stone_blue);
		registerRenderBlock(coloured_stone_light_green);
		registerRenderBlock(coloured_stone_green);
		registerRenderBlock(coloured_stone_yellow);
		registerRenderBlock(coloured_stone_orange);
		registerRenderBlock(coloured_stone_brown);
		registerRenderBlock(coloured_stone_magenta);
		registerRenderBlock(coloured_stone_purple);
		registerRenderBlock(coloured_stone_red);
		registerRenderBlock(coloured_stone_pink);
		registerRenderBlock(colour_changing_stone);
		registerRenderBlock(glowing_coloured_stone_white);
		registerRenderBlock(glowing_coloured_stone_light_gray);
		registerRenderBlock(glowing_coloured_stone_gray);
		registerRenderBlock(glowing_coloured_stone_black);
		registerRenderBlock(glowing_coloured_stone_light_blue);
		registerRenderBlock(glowing_coloured_stone_cyan);
		registerRenderBlock(glowing_coloured_stone_blue);
		registerRenderBlock(glowing_coloured_stone_light_green);
		registerRenderBlock(glowing_coloured_stone_green);
		registerRenderBlock(glowing_coloured_stone_yellow);
		registerRenderBlock(glowing_coloured_stone_orange);
		registerRenderBlock(glowing_coloured_stone_brown);
		registerRenderBlock(glowing_coloured_stone_magenta);
		registerRenderBlock(glowing_coloured_stone_purple);
		registerRenderBlock(glowing_coloured_stone_red);
		registerRenderBlock(glowing_coloured_stone_pink);
		registerRenderBlock(glowing_colour_changing_stone);
		// Coloured cobblestone
		registerRenderBlock(coloured_cobblestone_white);
		registerRenderBlock(coloured_cobblestone_light_gray);
		registerRenderBlock(coloured_cobblestone_gray);
		registerRenderBlock(coloured_cobblestone_black);
		registerRenderBlock(coloured_cobblestone_light_blue);
		registerRenderBlock(coloured_cobblestone_cyan);
		registerRenderBlock(coloured_cobblestone_blue);
		registerRenderBlock(coloured_cobblestone_light_green);
		registerRenderBlock(coloured_cobblestone_green);
		registerRenderBlock(coloured_cobblestone_yellow);
		registerRenderBlock(coloured_cobblestone_orange);
		registerRenderBlock(coloured_cobblestone_brown);
		registerRenderBlock(coloured_cobblestone_magenta);
		registerRenderBlock(coloured_cobblestone_purple);
		registerRenderBlock(coloured_cobblestone_red);
		registerRenderBlock(coloured_cobblestone_pink);
		registerRenderBlock(colour_changing_cobblestone);
		registerRenderBlock(glowing_coloured_cobblestone_white);
		registerRenderBlock(glowing_coloured_cobblestone_light_gray);
		registerRenderBlock(glowing_coloured_cobblestone_gray);
		registerRenderBlock(glowing_coloured_cobblestone_black);
		registerRenderBlock(glowing_coloured_cobblestone_light_blue);
		registerRenderBlock(glowing_coloured_cobblestone_cyan);
		registerRenderBlock(glowing_coloured_cobblestone_blue);
		registerRenderBlock(glowing_coloured_cobblestone_light_green);
		registerRenderBlock(glowing_coloured_cobblestone_green);
		registerRenderBlock(glowing_coloured_cobblestone_yellow);
		registerRenderBlock(glowing_coloured_cobblestone_orange);
		registerRenderBlock(glowing_coloured_cobblestone_brown);
		registerRenderBlock(glowing_coloured_cobblestone_magenta);
		registerRenderBlock(glowing_coloured_cobblestone_purple);
		registerRenderBlock(glowing_coloured_cobblestone_red);
		registerRenderBlock(glowing_coloured_cobblestone_pink);
		registerRenderBlock(glowing_colour_changing_cobblestone);
		// Seamless blocks
		registerRenderBlock(seamless_stone_slab);
		registerRenderBlock(seamless_oak_log);
		registerRenderBlock(seamless_birch_log);
		registerRenderBlock(seamless_spruce_log);
		registerRenderBlock(seamless_jungle_log);
		registerRenderBlock(seamless_acacia_log);
		registerRenderBlock(seamless_dark_oak_log);
		registerRenderBlock(seamless_smooth_sandstone);
		registerRenderBlock(seamless_smooth_red_sandstone);
		// Map making blocks
		registerRenderBlock(invisible_pressure_plate);
		registerRenderBlock(glowing_barrier);
		registerRenderBlock(glowing_air);
		registerRenderBlock(block_of_death);
		// Chest
		registerRenderBlock(iron_chest);
		// Machines
		registerRenderBlock(crusher);
		// Flowers
		registerRenderBlock(yellow_tulip);
		registerRenderBlock(blue_tulip);
		registerRenderBlock(black_tulip);
		registerRenderBlock(green_tulip);
		registerRenderBlock(purple_tulip);
		// Misc blocks
		registerRenderBlock(null_block);
		registerRenderBlock(scaffolding_block);
		registerRenderBlock(colour_changing_wool);
		registerRenderBlock(colour_changing_clay);
		registerRenderBlock(colour_changing_glass);
		// Stone blocks
		registerRenderBlock(basalt);
		registerRenderBlock(basalt_bricks);
		registerRenderBlock(polished_basalt);
		registerRenderBlock(polished_stone);
		registerRenderBlock(granite_bricks);
		registerRenderBlock(andesite_bricks);
		registerRenderBlock(diorite_bricks);
		registerRenderBlock(sandy_bricks);
		registerRenderBlock(sandy_stone_bricks);
		// Nether blocks
		registerRenderBlock(dark_nether_bricks);
		// Patterns
		registerRenderItem(wooden_pattern);
		registerRenderItem(wooden_pattern_bars);
		registerRenderItem(wooden_pattern_button);
		registerRenderItem(wooden_pattern_pressure_plate);
		registerRenderItem(wooden_pattern_trapdoor);
		registerRenderItem(wooden_pattern_wall);
		registerRenderItem(wooden_pattern_fence);
		registerRenderItem(wooden_pattern_fence_gate);
		registerRenderItem(wooden_pattern_stairs);
	}

	public static void registerRenderItem(Item item) {
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0,
				new ModelResourceLocation(Reference.modid + ":" + item.getUnlocalizedName().substring(5), "inventory"));
	}

	public static void registerRenderBlock(Block block) {
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(block), 0,
				new ModelResourceLocation(
						Reference.modid + ":" + Item.getItemFromBlock(block).getUnlocalizedName().substring(5),
						"inventory"));
	}

	public static void removeCrafting() {
		if (Config.crafting == true) {
			RecipeRemover.removeCraftingRecipeBlockWithMetadata(Blocks.STONE, 2);
			RecipeRemover.removeCraftingRecipeBlockWithMetadata(Blocks.STONE, 4);
			RecipeRemover.removeCraftingRecipeBlockWithMetadata(Blocks.STONE, 6);
		}
	}

	public static void registerGuiHandlers() {
		NetworkRegistry.INSTANCE.registerGuiHandler(Reference.modid, new GuiHandlerIronChest());
	}

	public static void registerEventHandlers() {
		MinecraftForge.EVENT_BUS.register(new Shield(0, null, creativeTab));
	}

	public static void crafting() {
		if (Config.crafting == true) {
			// Mineral blocks
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_block), "AAA", "AAA", "AAA", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_block), "JJJ", "JJJ", "JJJ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_block), "CCC", "CCC", "CCC", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.tin_block), "TTT", "TTT", "TTT", 'T',
					ModElements.tin_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_block), "BBB", "BBB", "BBB", 'B',
					ModElements.bronze_ingot);
			// Minerals
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst, 9),
					new ItemStack(ModElements.amethyst_block));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade, 9), new ItemStack(ModElements.jade_block));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_ingot, 9),
					new ItemStack(ModElements.copper_block));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.tin_ingot, 9),
					new ItemStack(ModElements.tin_block));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_ingot, 9),
					new ItemStack(ModElements.bronze_block));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_ingot, 1),
					new Object[] { ModElements.tin_ingot, ModElements.copper_ingot, ModElements.copper_ingot,
							ModElements.copper_ingot });
			GameRegistry.addSmelting(ModElements.amethyst_ore, new ItemStack(ModElements.amethyst), 1.2F);
			GameRegistry.addSmelting(ModElements.jade_ore, new ItemStack(ModElements.jade), 1.2F);
			GameRegistry.addSmelting(ModElements.copper_ore, new ItemStack(ModElements.copper_ingot), 0.7F);
			GameRegistry.addSmelting(ModElements.tin_ore, new ItemStack(ModElements.tin_ingot), 0.7F);
			// Tools
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "S  ", " S ", "   ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), " S ", "  S", "   ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), " S ", "  S", "   ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "S  ", " S ", "   ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "   ", "S  ", " S ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "   ", " S ", "  S", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "   ", " S ", "  S", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shears), "   ", "S  ", " S ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "G  ", " G ", "   ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), " G ", "  G", "   ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), " G ", "  G", "   ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "G  ", " G ", "   ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "   ", "G  ", " G ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "   ", " G ", "  G", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "   ", " G ", "  G", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "   ", "G  ", " G ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shears), "G  ", " G ", "   ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), " D ", "  D", "   ", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), " D ", "  D", "   ", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), "D  ", " D ", "   ", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), "   ", "D  ", " D ", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), "   ", " D ", "  D", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), "   ", " D ", "  D", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shears), "   ", "D  ", " D ", 'D', Items.DIAMOND);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_multitool, 1),
					new Object[] { Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL,
							Items.DIAMOND_HOE });
			GameRegistry.addRecipe(new ItemStack(ModElements.op_multitool), "AMA", "MNM", "AMA", 'A',
					ModElements.amethyst_block, 'M', ModElements.amethyst_multitool, 'N', Items.NETHER_STAR);
			GameRegistry.addRecipe(new ItemStack(ModElements.op_multitool), "MAM", "ANA", "MAM", 'A',
					ModElements.amethyst_block, 'M', ModElements.amethyst_multitool, 'N', Items.NETHER_STAR);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_pickaxe), "AAA", " S ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_axe), "AA ", "AS ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_axe), " AA", " SA", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_axe), " AA", " AS", "  S", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_axe), "AA ", "SA ", "S  ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shovel), " A ", " S ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shovel), "A  ", "S  ", "S  ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shovel), "  A", "  S", "  S", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_hoe), "AA ", " S ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_hoe), " AA", " S ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_hoe), "AA ", "S  ", "S  ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_hoe), " AA", "  S", "  S", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), " A ", "  A", "   ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), " A ", "  A", "   ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), "A  ", " A ", "   ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), "   ", "A  ", " A ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), "   ", " A ", "  A", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), "   ", " A ", "  A", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shears), "   ", "A  ", " A ", 'A',
					ModElements.amethyst);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_multitool, 1),
					new Object[] { ModElements.amethyst_sword, ModElements.amethyst_pickaxe, ModElements.amethyst_axe,
							ModElements.amethyst_shovel, ModElements.amethyst_hoe });
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_pickaxe), "JJJ", " S ", " S ", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_axe), "JJ ", "JS ", " S ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_axe), " JJ", " SJ", " S ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_axe), " JJ", " JS", "  S", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_axe), "JJ ", "SJ ", "S  ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shovel), " J ", " S ", " S ", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shovel), "J  ", "S  ", "S  ", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shovel), "  J", "  S", "  S", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_hoe), "JJ ", " S ", " S ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_hoe), " JJ", " S ", " S ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_hoe), "JJ ", "S  ", "S  ", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_hoe), " JJ", "  S", "  S", 'J', ModElements.jade, 'S',
					Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), " J ", "  J", "   ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), " J ", "  J", "   ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), "J  ", " J ", "   ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), "   ", "J  ", " J ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), "   ", " J ", "  J", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), "   ", " J ", "  J", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shears), "   ", "J  ", " J ", 'J', ModElements.jade);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_multitool, 1),
					new Object[] { ModElements.jade_sword, ModElements.jade_pickaxe, ModElements.jade_axe,
							ModElements.jade_shovel, ModElements.jade_hoe });
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_pickaxe), "CCC", " S ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_axe), "CC ", "CS ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_axe), " CC", " SC", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_axe), " CC", " CS", "  S", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_axe), "CC ", "SC ", "S  ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shovel), " C ", " S ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shovel), "C  ", "S  ", "S  ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shovel), "  C", "  S", "  S", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_hoe), "CC ", " S ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_hoe), " CC", " S ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_hoe), "CC ", "S  ", "S  ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_hoe), " CC", "  S", "  S", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), " C ", "  C", "   ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), " C ", "  C", "   ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), "C  ", " C ", "   ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), "   ", "C  ", " C ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), "   ", " C ", "  C", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), "   ", " C ", "  C", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shears), "   ", "C  ", " C ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_multitool, 1),
					new Object[] { ModElements.copper_sword, ModElements.copper_pickaxe, ModElements.copper_axe,
							ModElements.copper_shovel, ModElements.copper_hoe });
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_pickaxe), "BBB", " S ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_axe), "BB ", "BS ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_axe), " BB", " SB", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_axe), " BB", " BS", "  S", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_axe), "BB ", "SB ", "S  ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shovel), " B ", " S ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shovel), "B  ", "S  ", "S  ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shovel), "  B", "  S", "  S", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_hoe), "BB ", " S ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_hoe), " BB", " S ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_hoe), "BB ", "S  ", "S  ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_hoe), " BB", "  S", "  S", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), " B ", "  B", "   ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), " B ", "  B", "   ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), "B  ", " B ", "   ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), "   ", "B  ", " B ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), "   ", " B ", "  B", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), "   ", " B ", "  B", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shears), "   ", "B  ", " B ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_multitool, 1),
					new Object[] { ModElements.bronze_sword, ModElements.bronze_pickaxe, ModElements.bronze_axe,
							ModElements.bronze_shovel, ModElements.bronze_hoe });
			// Weapons
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.stone_bow, 1),
					new Object[] { Blocks.STONE, Items.BOW });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.iron_bow, 1),
					new Object[] { Items.IRON_INGOT, Items.BOW });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.gold_bow, 1),
					new Object[] { Items.GOLD_INGOT, Items.BOW });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_bow, 1),
					new Object[] { Items.DIAMOND, Items.BOW });
			GameRegistry.addRecipe(new ItemStack(ModElements.op_bow), "AAA", "ABA", "AAA", 'A',
					ModElements.amethyst_block, 'B', Items.BOW);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_sword), " J ", " J ", " S ", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_sword), "J  ", "J  ", "S  ", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_sword), "  J", "  J", "  S", 'J', ModElements.jade,
					'S', Items.STICK);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_bow, 1),
					new Object[] { ModElements.jade, Items.BOW });
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_sword), " A ", " A ", " S ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_sword), "A  ", "A  ", "S  ", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_sword), "  A", "  A", "  S", 'A',
					ModElements.amethyst, 'S', Items.STICK);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_bow, 1),
					new Object[] { ModElements.amethyst, Items.BOW });
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_sword), " C ", " C ", " S ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_sword), "C  ", "C  ", "S  ", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_sword), "  C", "  C", "  S", 'C',
					ModElements.copper_ingot, 'S', Items.STICK);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_bow, 1),
					new Object[] { ModElements.copper_ingot, Items.BOW });
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_sword), " B ", " B ", " S ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_sword), "B  ", "B  ", "S  ", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_sword), "  B", "  B", "  S", 'B',
					ModElements.bronze_ingot, 'S', Items.STICK);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_bow, 1),
					new Object[] { ModElements.bronze_ingot, Items.BOW });
			// Shields
			GameRegistry.addRecipe(new ItemStack(ModElements.stone_shield), "SSS", "SSS", " S ", 'S', Blocks.STONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.iron_shield), "III", "III", " I ", 'I', Items.IRON_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.gold_shield), "GGG", "GGG", " G ", 'G', Items.GOLD_INGOT);
			GameRegistry.addRecipe(new ItemStack(ModElements.diamond_shield), "DDD", "DDD", " D ", 'D', Items.DIAMOND);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_shield), "CCC", "CCC", " C ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_shield), "BBB", "BBB", " B ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_shield), "JJJ", "JJJ", " J ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_shield), "AAA", "AAA", " A ", 'A',
					ModElements.amethyst);
			// Armour
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_helmet), "AAA", "A A", "   ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_helmet), "   ", "AAA", "A A", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_chestplate), "A A", "AAA", "AAA", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_leggings), "AAA", "A A", "A A", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_boots), "   ", "A A", "A A", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.amethyst_boots), "A A", "A A", "   ", 'A',
					ModElements.amethyst);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_helmet), "JJJ", "J J", "   ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_helmet), "   ", "JJJ", "J J", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_chestplate), "J J", "JJJ", "JJJ", 'J',
					ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_leggings), "JJJ", "J J", "J J", 'J',
					ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_boots), "   ", "J J", "J J", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.jade_boots), "J J", "J J", "   ", 'J', ModElements.jade);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_helmet), "CCC", "C C", "   ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_helmet), "   ", "CCC", "C C", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_chestplate), "C C", "CCC", "CCC", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_leggings), "CCC", "C C", "C C", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_boots), "   ", "C C", "C C", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.copper_boots), "C C", "C C", "   ", 'C',
					ModElements.copper_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_helmet), "BBB", "B B", "   ", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_helmet), "   ", "BBB", "B B", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_chestplate), "B B", "BBB", "BBB", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_leggings), "BBB", "B B", "B B", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_boots), "   ", "B B", "B B", 'B',
					ModElements.bronze_ingot);
			GameRegistry.addRecipe(new ItemStack(ModElements.bronze_boots), "B B", "B B", "   ", 'B',
					ModElements.bronze_ingot);
			// Pressure plates
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, Items.DIAMOND });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, ModElements.copper_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.tin_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, ModElements.tin_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, ModElements.bronze_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, ModElements.amethyst });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, ModElements.jade });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.emerald_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, Items.EMERALD });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_pressure_plate),
					new Object[] { ModElements.wooden_pattern_pressure_plate, Items.QUARTZ });
			// Bars
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.stone_bars),
					new Object[] { ModElements.wooden_pattern_bars, Blocks.STONE });
			if (Config.craft_vanilla_blocks_with_patterns == true) {
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.IRON_BARS),
						new Object[] { ModElements.wooden_pattern_bars, Items.IRON_INGOT });
			}
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.gold_bars),
					new Object[] { ModElements.wooden_pattern_bars, Items.GOLD_INGOT });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_bars),
					new Object[] { ModElements.wooden_pattern_bars, Items.DIAMOND });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_bars),
					new Object[] { ModElements.wooden_pattern_bars, ModElements.copper_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.tin_bars),
					new Object[] { ModElements.wooden_pattern_bars, ModElements.tin_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_bars),
					new Object[] { ModElements.wooden_pattern_bars, ModElements.bronze_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_bars),
					new Object[] { ModElements.wooden_pattern_bars, ModElements.amethyst });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_bars),
					new Object[] { ModElements.wooden_pattern_bars, ModElements.jade });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.emerald_bars),
					new Object[] { ModElements.wooden_pattern_bars, Items.EMERALD });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.quartz_bars),
					new Object[] { ModElements.wooden_pattern_bars, Items.QUARTZ });
			// Trap doors
			if (Config.craft_vanilla_blocks_with_patterns == true) {
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.TRAPDOOR),
						new Object[] { ModElements.wooden_pattern_trapdoor, Blocks.PLANKS });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.IRON_TRAPDOOR),
						new Object[] { ModElements.wooden_pattern_trapdoor, Items.IRON_INGOT });
			}
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.stone_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, Blocks.STONE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.gold_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, Items.GOLD_INGOT });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, Items.DIAMOND });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.emerald_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, Items.EMERALD });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.quartz_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, Items.QUARTZ });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, ModElements.copper_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.tin_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, ModElements.tin_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, ModElements.bronze_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, ModElements.amethyst });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_trapdoor),
					new Object[] { ModElements.wooden_pattern_trapdoor, ModElements.jade });
			// Buttons
			if (Config.craft_vanilla_blocks_with_patterns == true) {
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.WOODEN_BUTTON),
						new Object[] { ModElements.wooden_pattern_button, Blocks.PLANKS });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.STONE_BUTTON),
						new Object[] { ModElements.wooden_pattern_button, Blocks.STONE });
			}
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.iron_button),
					new Object[] { ModElements.wooden_pattern_button, Items.IRON_INGOT });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.gold_button),
					new Object[] { ModElements.wooden_pattern_button, Items.GOLD_INGOT });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.diamond_button),
					new Object[] { ModElements.wooden_pattern_button, Items.DIAMOND });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.copper_button),
					new Object[] { ModElements.wooden_pattern_button, ModElements.copper_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.tin_button),
					new Object[] { ModElements.wooden_pattern_button, ModElements.tin_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.bronze_button),
					new Object[] { ModElements.wooden_pattern_button, ModElements.bronze_ingot });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.amethyst_button),
					new Object[] { ModElements.wooden_pattern_button, ModElements.amethyst });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.jade_button),
					new Object[] { ModElements.wooden_pattern_button, ModElements.jade });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.emerald_button),
					new Object[] { ModElements.wooden_pattern_button, Items.EMERALD });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.quartz_button),
					new Object[] { ModElements.wooden_pattern_button, Items.QUARTZ });
			// Fence
			if (Config.craft_vanilla_blocks_with_patterns == true) {
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.OAK_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 0) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.SPRUCE_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 1) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.BIRCH_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 2) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.JUNGLE_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 3) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.ACACIA_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 4) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.DARK_OAK_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, new ItemStack(Blocks.PLANKS, 1, 5) });
				GameRegistry.addShapelessRecipe(new ItemStack(Blocks.NETHER_BRICK_FENCE),
						new Object[] { ModElements.wooden_pattern_fence, Blocks.NETHER_BRICK });
			}
			// Fence gates
			/*
			 * GameRegistry.addShapelessRecipe(new
			 * ItemStack(ModElements.nether_bricks_fence_gate), new Object[] {
			 * ModElements.wooden_pattern_fence_gate, Blocks.NETHER_BRICK });
			 * GameRegistry.addShapelessRecipe(new
			 * ItemStack(ModElements.dark_nether_bricks_fence_gate), new
			 * Object[] { ModElements.wooden_pattern_fence_gate,
			 * ModElements.dark_nether_bricks });
			 */
			// Colour blocks
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 4),
					new Object[] { new ItemStack(ModElements.tin_ingot), new ItemStack(ModElements.tin_ingot),
							new ItemStack(Items.IRON_INGOT), new ItemStack(Items.IRON_INGOT) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_black, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 0) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_light_gray, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 7) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_gray, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 8) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_light_blue, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 12) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_cyan, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 6) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_blue, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 4) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_light_green, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 10) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_green, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 2) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_red, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_orange, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 14) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_brown, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 3) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_magenta, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 13) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_purple, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 5) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_yellow, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 11) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_pink, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Items.DYE, 1, 9) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_black) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_light_gray) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_gray) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_light_blue) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_cyan) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_blue) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_light_green) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_green) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_red) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_orange) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_brown) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_magenta) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_purple) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_yellow) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_pink) });
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_block), " D ", "DCD", " D ", 'D',
					Items.DYE, 'C', ModElements.colour_block_white);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.colour_block_white), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_black, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 0) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_light_gray, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_white),
							new ItemStack(Items.DYE, 1, 7) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_gray, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 8) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_light_blue, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_white),
							new ItemStack(Items.DYE, 1, 12) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_cyan, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 6) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_blue, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 4) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_light_green, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_white),
							new ItemStack(Items.DYE, 1, 10) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_green, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 2) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_red, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_orange, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 14) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_brown, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 3) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_magenta, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 13) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_purple, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 5) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_yellow, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 11) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_pink, 1), new Object[] {
					new ItemStack(ModElements.glowing_colour_block_white), new ItemStack(Items.DYE, 1, 9) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_black) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_light_gray) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_gray) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_light_blue) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_cyan) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_blue) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_light_green) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_green) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_red) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_orange) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_brown) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_magenta) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_purple) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_yellow) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_colour_block_white, 1),
					new Object[] { new ItemStack(ModElements.glowing_colour_block_pink) });
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_block), " D ", "DCD", " D ", 'D',
					Items.DYE, 'C', ModElements.glowing_colour_block_white);
			// Coloured stone bricks
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_white, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 15) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_black, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 0) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_light_gray, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 7) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_gray, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 8) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_light_blue, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 12) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_cyan, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 6) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_blue, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 4) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_light_green, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 10) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_green, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 2) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_red, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_orange, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 14) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_brown, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 3) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_magenta, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 13) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_purple, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 5) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_yellow, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 11) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_bricks_pink, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 9) });
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_stone_bricks), " D ", "DSD", " D ", 'D',
					Items.DYE, 'S', Blocks.STONEBRICK);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_white, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 15),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_black, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 0),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_light_gray, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 7),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_gray, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 8),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_light_blue, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 12),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_cyan, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 6),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_blue, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 4),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_light_green, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 10),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_green, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 2),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_red, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 1),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_orange, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 14),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_brown, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 3),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_magenta, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 13),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_purple, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 5),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_yellow, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 11),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_bricks_pink, 1),
					new Object[] { new ItemStack(Blocks.STONEBRICK), new ItemStack(Items.DYE, 1, 9),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_stone_bricks), "GDG", "DSD", "GDG",
					'D', Items.DYE, 'S', Blocks.STONEBRICK, 'G', Blocks.GLOWSTONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_stone_bricks), "DGD", "GSG", "DGD",
					'D', Items.DYE, 'S', Blocks.STONEBRICK, 'G', Blocks.GLOWSTONE);
			// Coloured stone
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_white, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 15) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_black, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 0) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_light_gray, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 7) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_gray, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 8) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_light_blue, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 12) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_cyan, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 6) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_blue, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 4) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_light_green, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 10) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_green, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 2) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_red, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_orange, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 14) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_brown, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 3) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_magenta, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 13) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_purple, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 5) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_yellow, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 11) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_stone_pink, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 9) });
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_stone), " D ", "DSD", " D ", 'D',
					Items.DYE, 'S', Blocks.STONE);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_white, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 15), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_black, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 0), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_light_gray, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 7),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_gray, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 8), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_light_blue, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 12),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_cyan, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 6), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_blue, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 4), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_light_green, 1),
					new Object[] { new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 10),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_green, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 2), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_red, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 1), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_orange, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 14), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_brown, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 3), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_magenta, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 13), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_purple, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 5), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_yellow, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 11), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_stone_pink, 1), new Object[] {
					new ItemStack(Blocks.STONE), new ItemStack(Items.DYE, 1, 9), new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_stone), "GDG", "DSD", "GDG", 'D',
					Items.DYE, 'S', Blocks.STONE, 'G', Blocks.GLOWSTONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_stone), "DGD", "GSG", "DGD", 'D',
					Items.DYE, 'S', Blocks.STONE, 'G', Blocks.GLOWSTONE);
			// Coloured cobblestone
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_white, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 15) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_black, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 0) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_light_gray, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 7) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_gray, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 8) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_light_blue, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 12) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_cyan, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 6) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_blue, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 4) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_light_green, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 10) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_green, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 2) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_red, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_orange, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 14) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_brown, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 3) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_magenta, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 13) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_purple, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 5) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_yellow, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 11) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.coloured_cobblestone_pink, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 9) });
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_cobblestone), " D ", "DCD", " D ", 'D',
					Items.DYE, 'C', Blocks.COBBLESTONE);
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_white, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 15),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_black, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 0),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_light_gray, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 7),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_gray, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 8),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_light_blue, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 12),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_cyan, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 6),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_blue, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 4),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_light_green, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 10),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_green, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 2),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_red, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 1),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_orange, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 14),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_brown, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 3),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_magenta, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 13),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_purple, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 5),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_yellow, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 11),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.glowing_coloured_cobblestone_pink, 1),
					new Object[] { new ItemStack(Blocks.COBBLESTONE), new ItemStack(Items.DYE, 1, 9),
							new ItemStack(Blocks.GLOWSTONE) });
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_cobblestone), "GDG", "DCD", "GDG",
					'D', Items.DYE, 'C', Blocks.COBBLESTONE, 'G', Blocks.GLOWSTONE);
			GameRegistry.addRecipe(new ItemStack(ModElements.glowing_colour_changing_cobblestone), "DGD", "GCG", "DGD",
					'D', Items.DYE, 'C', Blocks.COBBLESTONE, 'G', Blocks.GLOWSTONE);
			// Seamless blocks
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_stone_slab, 4), "SS ", "SS ", "   ", 'S',
					new ItemStack(Blocks.STONE_SLAB, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_stone_slab, 4), " SS", " SS", "   ", 'S',
					new ItemStack(Blocks.STONE_SLAB, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_stone_slab, 4), "   ", "SS ", "SS ", 'S',
					new ItemStack(Blocks.STONE_SLAB, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_stone_slab, 4), "   ", " SS", " SS", 'S',
					new ItemStack(Blocks.STONE_SLAB, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_oak_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_oak_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_oak_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_oak_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_birch_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_birch_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_birch_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_birch_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_spruce_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_spruce_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_spruce_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_spruce_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_jungle_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_jungle_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_jungle_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_jungle_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_acacia_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG2, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_acacia_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG2, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_acacia_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG2, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_acacia_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG2, 1, 0));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_dark_oak_log, 4), "LL ", "LL ", "   ", 'L',
					new ItemStack(Blocks.LOG2, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_dark_oak_log, 4), " LL", " LL", "   ", 'L',
					new ItemStack(Blocks.LOG2, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_dark_oak_log, 4), "   ", "LL ", "LL ", 'L',
					new ItemStack(Blocks.LOG2, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_dark_oak_log, 4), "   ", " LL", " LL", 'L',
					new ItemStack(Blocks.LOG2, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_sandstone, 4), "SS ", "SS ", "   ", 'S',
					new ItemStack(Blocks.SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_sandstone, 4), " SS", " SS", "   ", 'S',
					new ItemStack(Blocks.SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_sandstone, 4), "   ", "SS ", "SS ", 'S',
					new ItemStack(Blocks.SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_sandstone, 4), "   ", " SS", " SS", 'S',
					new ItemStack(Blocks.SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_red_sandstone, 4), "SS ", "SS ", "   ",
					'S', new ItemStack(Blocks.RED_SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_red_sandstone, 4), " SS", " SS", "   ",
					'S', new ItemStack(Blocks.RED_SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_red_sandstone, 4), "   ", "SS ", "SS ",
					'S', new ItemStack(Blocks.RED_SANDSTONE, 1, 2));
			GameRegistry.addRecipe(new ItemStack(ModElements.seamless_smooth_red_sandstone, 4), "   ", " SS", " SS",
					'S', new ItemStack(Blocks.RED_SANDSTONE, 1, 2));
			// Flowers to dyes
			GameRegistry.addShapelessRecipe(new ItemStack(Items.DYE, 1, 4), ModElements.blue_tulip);
			GameRegistry.addShapelessRecipe(new ItemStack(Items.DYE, 1, 0), ModElements.black_tulip);
			GameRegistry.addShapelessRecipe(new ItemStack(Items.DYE, 1, 2), ModElements.green_tulip);
			GameRegistry.addShapelessRecipe(new ItemStack(Items.DYE, 1, 11), ModElements.yellow_tulip);
			GameRegistry.addShapelessRecipe(new ItemStack(Items.DYE, 1, 5), ModElements.purple_tulip);
			// Colour changing blocks
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_wool), " D ", "DWD", " D ", 'D', Items.DYE,
					'W', Blocks.WOOL);
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_clay), " D ", "DCD", " D ", 'D', Items.DYE,
					'C', Blocks.STAINED_HARDENED_CLAY);
			GameRegistry.addRecipe(new ItemStack(ModElements.colour_changing_glass), " D ", "DGD", " D ", 'D',
					Items.DYE, 'G', Blocks.STAINED_GLASS);
			// Machines
			GameRegistry.addRecipe(new ItemStack(ModElements.crusher), "SPS", "RTR", "SPS", 'S', Blocks.STONE, 'P',
					Blocks.STICKY_PISTON, 'R', Items.REDSTONE, 'T', ModElements.tin_block);
			GameRegistry.addRecipe(new ItemStack(ModElements.crusher), "SRS", "PTP", "SRS", 'S', Blocks.STONE, 'P',
					Blocks.STICKY_PISTON, 'R', Items.REDSTONE, 'T', ModElements.tin_block);
			// Stone blocks
			GameRegistry.addRecipe(new ItemStack(ModElements.basalt_bricks, 4), "BB ", "BB ", "   ", 'B',
					ModElements.basalt);
			GameRegistry.addRecipe(new ItemStack(ModElements.basalt_bricks, 4), " BB", " BB", "   ", 'B',
					ModElements.basalt);
			GameRegistry.addRecipe(new ItemStack(ModElements.basalt_bricks, 4), "   ", "BB ", "BB ", 'B',
					ModElements.basalt);
			GameRegistry.addRecipe(new ItemStack(ModElements.basalt_bricks, 4), "   ", " BB", " BB", 'B',
					ModElements.basalt);
			GameRegistry.addRecipe(new ItemStack(ModElements.polished_basalt, 9), "BBB", "BBB", "BBB", 'B',
					ModElements.basalt);
			GameRegistry.addRecipe(new ItemStack(ModElements.polished_stone, 9), "SSS", "SSS", "SSS", 'S',
					new ItemStack(Blocks.STONE, 1, 0));
			GameRegistry.addRecipe(new ItemStack(Blocks.STONE, 9, 2), "GGG", "GGG", "GGG", 'G',
					new ItemStack(Blocks.STONE, 1, 1));
			GameRegistry.addRecipe(new ItemStack(Blocks.STONE, 9, 4), "DDD", "DDD", "DDD", 'D',
					new ItemStack(Blocks.STONE, 1, 3));
			GameRegistry.addRecipe(new ItemStack(Blocks.STONE, 9, 6), "AAA", "AAA", "AAA", 'A',
					new ItemStack(Blocks.STONE, 1, 5));
			GameRegistry.addRecipe(new ItemStack(ModElements.granite_bricks, 4), "GG ", "GG ", "   ", 'G',
					new ItemStack(Blocks.STONE, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.granite_bricks, 4), " GG", " GG", "   ", 'G',
					new ItemStack(Blocks.STONE, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.granite_bricks, 4), "   ", "GG ", "GG ", 'G',
					new ItemStack(Blocks.STONE, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.granite_bricks, 4), "   ", " GG", " GG", 'G',
					new ItemStack(Blocks.STONE, 1, 1));
			GameRegistry.addRecipe(new ItemStack(ModElements.diorite_bricks, 4), "DD ", "DD ", "   ", 'D',
					new ItemStack(Blocks.STONE, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.diorite_bricks, 4), " DD", " DD", "   ", 'D',
					new ItemStack(Blocks.STONE, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.diorite_bricks, 4), "   ", "DD ", "DD ", 'D',
					new ItemStack(Blocks.STONE, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.diorite_bricks, 4), "   ", " DD", " DD", 'D',
					new ItemStack(Blocks.STONE, 1, 3));
			GameRegistry.addRecipe(new ItemStack(ModElements.andesite_bricks, 4), "AA ", "AA ", "   ", 'A',
					new ItemStack(Blocks.STONE, 1, 5));
			GameRegistry.addRecipe(new ItemStack(ModElements.andesite_bricks, 4), " AA", " AA", "   ", 'A',
					new ItemStack(Blocks.STONE, 1, 5));
			GameRegistry.addRecipe(new ItemStack(ModElements.andesite_bricks, 4), "   ", "AA ", "AA ", 'A',
					new ItemStack(Blocks.STONE, 1, 5));
			GameRegistry.addRecipe(new ItemStack(ModElements.andesite_bricks, 4), "   ", " AA", " AA", 'A',
					new ItemStack(Blocks.STONE, 1, 5));
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.sandy_bricks),
					new Object[] { Blocks.SAND, Blocks.BRICK_BLOCK });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.sandy_stone_bricks),
					new Object[] { Blocks.SAND, Blocks.STONEBRICK });
			// Nether blocks
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.dark_nether_bricks),
					new Object[] { new ItemStack(Blocks.NETHER_BRICK), new ItemStack(Items.DYE, 1, 0) });
			// Wooden pattern
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "WS ", "SW ", "   ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), " WS", " SW", "   ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "   ", "WS ", "SW ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "   ", " WS", " SW", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "SW ", "WS ", "   ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), " SW", " WS", "   ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "   ", "SW ", "WS ", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			GameRegistry.addRecipe(new ItemStack(ModElements.wooden_pattern, 16), "   ", " SW", " WS", 'S',
					new ItemStack(Items.STICK), 'W', Blocks.PLANKS);
			// Wooden pattern bars
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, Blocks.IRON_BARS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.gold_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.diamond_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.copper_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.tin_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.bronze_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.amethyst_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.quartz_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.emerald_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.jade_bars });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars),
					new Object[] { ModElements.wooden_pattern, ModElements.stone_bars });
			// Wooden pattern button
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, Blocks.WOODEN_BUTTON });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, Blocks.STONE_BUTTON });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.gold_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.diamond_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.copper_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.tin_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.bronze_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.amethyst_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.jade_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.emerald_button });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button),
					new Object[] { ModElements.wooden_pattern, ModElements.quartz_button });
			// Wooden pattern pressure plate
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, Blocks.WOODEN_PRESSURE_PLATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, Blocks.STONE_PRESSURE_PLATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.diamond_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.emerald_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.quartz_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.tin_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.copper_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.bronze_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.amethyst_pressure_plate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate),
					new Object[] { ModElements.wooden_pattern, ModElements.jade_pressure_plate });
			// Wooden pattern trapdoor
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, Blocks.TRAPDOOR });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, Blocks.IRON_TRAPDOOR });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.gold_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.diamond_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.emerald_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.quartz_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.tin_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.copper_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.bronze_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.amethyst_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.jade_trapdoor });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor),
					new Object[] { ModElements.wooden_pattern, ModElements.stone_trapdoor });
			// Wooden pattern wall
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, Blocks.COBBLESTONE_WALL });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, new ItemStack(Blocks.COBBLESTONE_WALL, 1, 1) });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.iron_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.stone_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.gold_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.diamond_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.emerald_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.quartz_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.copper_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.tin_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.bronze_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.amethyst_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.jade_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.brick_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.stonebrick_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.granite_bricks_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.diorite_bricks_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.andesite_bricks_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.basalt_bricks_wall });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.sandy_stone_bricks_wall });
			// Wooden pattern fence
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.ACACIA_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.OAK_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.BIRCH_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.DARK_OAK_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.JUNGLE_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.DARK_OAK_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, Blocks.NETHER_BRICK_FENCE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.dark_nether_bricks_fence });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.red_nether_bricks_fence });
			// Wooden pattern fence gate
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.ACACIA_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.OAK_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.BIRCH_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.DARK_OAK_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.JUNGLE_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, Blocks.DARK_OAK_FENCE_GATE });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, ModElements.nether_bricks_fence_gate });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate),
					new Object[] { ModElements.wooden_pattern, ModElements.dark_nether_bricks_fence_gate });
			// Wooden pattern stairs
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.ACACIA_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.BIRCH_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.OAK_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.SPRUCE_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.DARK_OAK_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.JUNGLE_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.NETHER_BRICK_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.PURPUR_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.QUARTZ_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.SANDSTONE_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.RED_SANDSTONE_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.STONE_BRICK_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, Blocks.STONE_STAIRS });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.oak_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_oak_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.birch_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_birch_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.spruce_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_spruce_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.jungle_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_jungle_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.acacia_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_acacia_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.dark_oak_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_dark_oak_log_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.coal_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.iron_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.gold_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.lapis_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.redstone_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.diamond_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.copper_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.bronze_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.tin_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.jade_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.amethyst_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.stone_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.granite_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.andesite_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.diorite_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.basalt_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.granite_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.andesite_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.diorite_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.basalt_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.sandy_stone_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs), new Object[] {
					ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_smooth_sandstone_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs), new Object[] {
					ModElements.wooden_pattern, ModElementsSmallerBlocks.seamless_smooth_red_sandstone_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.prismarine_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.prismarine_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.dark_prismarine_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.obsidian_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.bone_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.end_stone_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.red_nether_bricks_stairs });
			GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs),
					new Object[] { ModElements.wooden_pattern, ModElementsSmallerBlocks.dark_nether_bricks_stairs });
			// Wooden pattern duplicate
			if (Config.duplicate_patterns == true) {
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_bars, 2), new Object[] {
						new ItemStack(ModElements.wooden_pattern), new ItemStack(ModElements.wooden_pattern_bars) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_button, 2), new Object[] {
						new ItemStack(ModElements.wooden_pattern), new ItemStack(ModElements.wooden_pattern_button) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_pressure_plate, 2),
						new Object[] { new ItemStack(ModElements.wooden_pattern),
								new ItemStack(ModElements.wooden_pattern_pressure_plate) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_trapdoor, 2),
						new Object[] { new ItemStack(ModElements.wooden_pattern),
								new ItemStack(ModElements.wooden_pattern_trapdoor) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_wall, 2), new Object[] {
						new ItemStack(ModElements.wooden_pattern), new ItemStack(ModElements.wooden_pattern_wall) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence, 2), new Object[] {
						new ItemStack(ModElements.wooden_pattern), new ItemStack(ModElements.wooden_pattern_fence) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_fence_gate, 2),
						new Object[] { new ItemStack(ModElements.wooden_pattern),
								new ItemStack(ModElements.wooden_pattern_fence_gate) });
				GameRegistry.addShapelessRecipe(new ItemStack(ModElements.wooden_pattern_stairs, 2), new Object[] {
						new ItemStack(ModElements.wooden_pattern), new ItemStack(ModElements.wooden_pattern_stairs) });
			}
			// Misc blocks
			GameRegistry.addRecipe(new ItemStack(ModElements.scaffolding_block, 16), "SSS", "S S", "SSS", 'S',
					Items.STICK);
		}
	}

	public static void registerAchievements() {
		copperMiner = new Achievement("achievement.copperminer", "copperminer", 0, 2, ModElements.copper_ore, null)
				.registerStat();
		tinMiner = new Achievement("achievement.tinminer", "tinminer", 0, 0, ModElements.tin_ore, null).registerStat();
		bronzeCreator = new Achievement("achievement.bronzecreator", "bronzecreator", -1, 1, ModElements.bronze_ingot,
				copperMiner).registerStat();
		amethystMiner = new Achievement("achievement.amethystminer", "amethystminer", -3, 1, ModElements.amethyst_ore,
				null).registerStat();
		diamondUpgrade = new Achievement("achievement.diamondUpgrade", "diamondUpgrade", 0, 4,
				ModElements.diamond_multitool, null).registerStat();
		amethystUpgrade = new Achievement("achievement.amethystUpgrade", "amethystUpgrade", -2, 4,
				ModElements.amethyst_multitool, diamondUpgrade).registerStat();
		theOpTool = new Achievement("achievement.theOpTool", "theOpTool", -4, 4, ModElements.op_multitool,
				amethystUpgrade).registerStat();
		moreFlowers = new Achievement("achievement.moreFlowers", "moreFlowers", 2, 0, ModElements.purple_tulip, null)
				.registerStat();

		AchievementPage.registerAchievementPage(new AchievementPage("MCrafterzz mod", new Achievement[] { copperMiner,
				tinMiner, bronzeCreator, amethystMiner, diamondUpgrade, amethystUpgrade, theOpTool, moreFlowers }));
		FMLCommonHandler.instance().bus().register(new AchievementEvents() {
		});
	}

	public static void registerStats() {
		open_crusher_gui = new StatBase("stats.open_crusher_gui",
				new TextComponentTranslation("stats.open_crusher_gui", new Object[0])).registerStat();
	}

}
