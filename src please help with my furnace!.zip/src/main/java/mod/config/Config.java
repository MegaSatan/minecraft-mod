package mod.config;

import java.io.File;

import mod.Reference;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class Config {

	public static Config instance = new Config();
	public static Configuration config;
	// Settings world gen
	public static boolean spawn_flowers = true;
	public static boolean spawn_tin = true;
	public static boolean spawn_copper = true;
	public static boolean spawn_jade = true;
	public static boolean spawn_amethyst = true;
	public static boolean spawn_basalt = true;
	// Setting crafting
	public static boolean crafting = true;
	public static boolean duplicate_patterns = true;
	public static boolean craft_vanilla_blocks_with_patterns = true;

	@SubscribeEvent
	public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent eventArgs) {
		if (eventArgs.getModID().equals(Reference.modid))
			Config.syncConfig();
	}

	public static void init(File file) {
		config = new Configuration(file);
		config.load();
		syncConfig();
	}

	public static void syncConfig() {
		String worldCategory = "worldgeneration";
		String craftingCategory = "crafting";

		config.setCategoryRequiresMcRestart(craftingCategory, true);
		config.addCustomCategoryComment(worldCategory, "World Generaration Settings");
		spawn_flowers = config.getBoolean("Spawn Flowers", worldCategory, true,
				"Turns on and off flower world generation (Only flowers from this mod)");
		spawn_copper = config.getBoolean("Spawn Copper", worldCategory, true,
				"Turns on and off copper world generation");
		spawn_tin = config.getBoolean("Spawn Tin", worldCategory, true, "Turns on and off tin world generation");
		spawn_jade = config.getBoolean("Spawn Jade", worldCategory, true, "Turns on and off jade world generation");
		spawn_amethyst = config.getBoolean("Spawn Amethyst", worldCategory, true,
				"Turns on and off amethyst world generation");
		spawn_basalt = config.getBoolean("Spawn Basalt", worldCategory, true,
				"Turns on and off basalt world generation");

		config.addCustomCategoryComment(craftingCategory, "Crafting Settings");
		crafting = config.getBoolean("Crafting", craftingCategory, true,
				"Turns on and off crafting of all items and blocks added by this mod");
		duplicate_patterns = config.getBoolean("Duplicate Patterns", craftingCategory, true,
				"Turns on and off duplication of wooden patterns, for example a wooden pattern and a wooden pattern wall crafts 2 wooden pattern walls");
		craft_vanilla_blocks_with_patterns = config.getBoolean("Craft Vanilla Blocks With Patterns", craftingCategory,
				true, "Enables crafting of vanilla blocks(buttons, trapdoors etc) with wooden patterns");
		config.save();
	}

	public static void resetConfig() {
		spawn_flowers = true;
		spawn_tin = true;
		spawn_copper = true;
		spawn_jade = true;
		spawn_amethyst = true;
		spawn_basalt = true;
		crafting = true;
		duplicate_patterns = true;
		craft_vanilla_blocks_with_patterns = true;
		config.save();
	}

}
