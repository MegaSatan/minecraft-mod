package mod.tileentitys;

import java.util.Arrays;

import mod.recipes.RecipesCrusher;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.EnumSkyBlock;

public class TileEntityCrusherTest {
/*
	// Slots
	public static int input_slots = 1;
	public static int fuel_slots = 1;
	public static int output_slots = 1;
	public static int total_slots = input_slots + fuel_slots + output_slots;

	public static int first_fuel_slot = 0;
	public static int first_imput_slot = first_fuel_slot + fuel_slots;
	public static int first_output_slot = first_imput_slot + input_slots;

	public ItemStack[] itemsInCrusher = new ItemStack[total_slots];
	public int[] burnTimeRemaining = new int[fuel_slots];
	public int[] burnTimeFuel = new int[fuel_slots];
	public int currentItemBurnTime;
	public int cookTime;
	public int cookTimeNeeded = 200;
	public int cachedNumberOfBurningSlots = -1;

	public String name = "Crusher";

	public int factionOfFuelRemaining(int fuelSlot) {
		if (burnTimeFuel[fuelSlot] <= 0) {
			return 0;
		}
		int fraction = burnTimeRemaining[fuelSlot] / burnTimeFuel[fuelSlot];
		return fraction;
	}

	public int secondsOfFuelRemaining(int fuelSlot) {
		if (burnTimeFuel[fuelSlot] <= 0) {
			return 0;
		}
		return burnTimeFuel[fuelSlot] / 20;
	}

	public int numberOfBurningFuelSlots() {
		int burningCount = 0;
		for (int burnTime : burnTimeRemaining) {
			if (burnTime > 0) {
				++burningCount;
			}
		}
		return burningCount;
	}

	public int fractionOfCookTimeComplete() {
		int fraction = cookTime / cookTimeNeeded;
		return fraction;
	}

	@Override
	public void update() {
		int numberOfFuelBurning = burnFuel();
		if (numberOfFuelBurning > 0) {
			cookTime += numberOfFuelBurning;
		} else {
			cookTime -= 2;
		}
		if (cookTime < 0) {
			cookTime = 0;
		}
		if (cookTime >= cookTimeNeeded) {
			smeltItem();
			cookTime = 0;
		} else {
			cookTime = 0;
		}
		int amountBurning = numberOfBurningFuelSlots();
		if (cachedNumberOfBurningSlots != amountBurning) {
			cachedNumberOfBurningSlots = amountBurning;
			if (worldObj.isRemote) {
				worldObj.markBlockRangeForRenderUpdate(pos, pos);
			}
			worldObj.checkLightFor(EnumSkyBlock.BLOCK, pos);
		}
	}

	public int burnFuel() {
		int amountBurning = 0;
		boolean inventoryChanged = false;
		for (int i = 0; i < fuel_slots; i++) {
			int fuelSlotNumber = i + first_fuel_slot;
			if (burnTimeRemaining[i] > 0) {
				--burnTimeRemaining[i];
				++amountBurning;
			}
			if (burnTimeRemaining[i] == 0) {
				if (itemsInCrusher[fuelSlotNumber] != null && getItemBurnTime(itemsInCrusher[fuelSlotNumber]) > 0) {
					burnTimeRemaining[i] = cookTimeNeeded[i] = getItemBurnTime(itemsInCrusher[fuelSlotNumber]);
					--itemsInCrusher[fuelSlotNumber].stackSize;
					inventoryChanged = true;
					if (itemsInCrusher[fuelSlotNumber].stackSize == 0) {
						itemsInCrusher[fuelSlotNumber] = itemsInCrusher[fuelSlotNumber].getItem()
								.getContainerItem(itemsInCrusher[fuelSlotNumber]);
					}
				}
			}
		}
		if (inventoryChanged == true) {
			markDirty();
		}
		return amountBurning;
	}

	public boolean canSmelt() {
		return smeltItem(false);
	}

	public void smeltItem() {
		smeltItem(true);
	}

	public boolean smeltItem(boolean smelt) {
		Integer firstSuitibleInputSlot = null;
		Integer firstSuitibleOutputSlot = null;
		ItemStack result = null;
		for (int inputSlot = first_imput_slot; inputSlot < first_imput_slot + input_slots; inputSlot++) {
			if (itemsInCrusher[inputSlot] != null) {
				result = getSmeltingResultForItem(itemsInCrusher[inputSlot]);
				if (result != null) {
					for (int outputSlot = first_output_slot; outputSlot < first_output_slot
							+ output_slots; outputSlot++) {
						ItemStack output = itemsInCrusher[outputSlot];
						if (output == null) {
							firstSuitibleInputSlot = inputSlot;
							firstSuitibleOutputSlot = outputSlot;
							break;
						}
						if (output.getItem() == result.getItem()
								&& (!output.getHasSubtypes() || output.getMetadata() == output.getMetadata())
								&& ItemStack.areItemStackTagsEqual(output, result)) {
							int combinedSize = itemsInCrusher[outputSlot].stackSize + result.stackSize;
							if (combinedSize <= getInventoryStackLimit()
									&& combinedSize <= itemsInCrusher[outputSlot].getMaxStackSize()) {
								firstSuitibleInputSlot = inputSlot;
								firstSuitibleOutputSlot = outputSlot;
								break;
							}
						}
					}
					if (firstSuitibleInputSlot != null) {
						break;
					}
				}
			}
		}
		if (firstSuitibleInputSlot == null) {
			return false;
		}
		if (!smelt) {
			return true;
		}
		itemsInCrusher[firstSuitibleInputSlot].stackSize--;
		if (itemsInCrusher[firstSuitibleInputSlot].stackSize <= 0) {
			itemsInCrusher[firstSuitibleInputSlot] = null;
		}
		if (itemsInCrusher[firstSuitibleInputSlot] == null) {
			itemsInCrusher[firstSuitibleInputSlot] = result.copy();
		} else {
			itemsInCrusher[firstSuitibleInputSlot].stackSize += result.stackSize;
		}
		markDirty();
		return true;
	}

	public ItemStack getItemSmeltingResultForItem(ItemStack itemStack) {
		return RecipesCrusher.instance().getCrushingResult(itemStack);
	}

	public static int getItemBurnTime(ItemStack stack) {
		if (stack == null) {
			return 0;
		} else {
			Item item = stack.getItem();

			if (item instanceof ItemBlock && Block.getBlockFromItem(item) != Blocks.AIR) {
				Block block = Block.getBlockFromItem(item);

				if (block == Blocks.WOODEN_SLAB) {
					return 150;
				}

				if (block.getDefaultState().getMaterial() == Material.WOOD) {
					return 300;
				}

				if (block == Blocks.COAL_BLOCK) {
					return 16000;
				}
			}

			if (item instanceof ItemTool && ((ItemTool) item).getToolMaterialName().equals("WOOD"))
				return 200;
			if (item instanceof ItemSword && ((ItemSword) item).getToolMaterialName().equals("WOOD"))
				return 200;
			if (item instanceof ItemHoe && ((ItemHoe) item).getMaterialName().equals("WOOD"))
				return 200;
			if (item == Items.STICK)
				return 100;
			if (item == Items.COAL)
				return 1600;
			if (item == Items.LAVA_BUCKET)
				return 20000;
			if (item == Item.getItemFromBlock(Blocks.SAPLING))
				return 100;
			if (item == Items.BLAZE_ROD)
				return 2400;
			return net.minecraftforge.fml.common.registry.GameRegistry.getFuelValue(stack);
		}
	}

	@Override
	public int getSizeInventory() {
		return itemsInCrusher.length;
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return itemsInCrusher[slot];
	}

	@Override
	public ItemStack decrStackSize(int slot, int count) {
		ItemStack itemStackInSlot = getStackInSlot(slot);
		if (itemStackInSlot == null) {
			return null;
		}
		ItemStack itemStackRemoved;
		if (itemStackInSlot.stackSize <= count) {
			itemStackRemoved = itemStackInSlot;
			setInventorySlotContents(slot, null);
		} else {
			itemStackRemoved = itemStackInSlot.splitStack(count);
			if (itemStackInSlot.stackSize == 0) {
				setInventorySlotContents(slot, null);
			}
		}
		markDirty();
		return itemStackRemoved;
	}

	@Override
	public void setInventorySlotContents(int slot, ItemStack itemStack) {
		itemsInCrusher[slot] = itemStack;
		if (itemStack != null && itemStack.stackSize > getInventoryStackLimit()) {
			itemStack.stackSize = getInventoryStackLimit();
		}
		markDirty();
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean isUseableByPlayer(EntityPlayer player) {
		if (this.worldObj.getTileEntity(this.pos) != this) {
			return false;
		}
		double x_center_offset = 0.5;
		double y_center_offset = 0.5;
		double z_center_offset = 0.5;
		double maxinum_distance_sq = 8.0 * 8.0;
		return player.getDistanceSq(pos.getX() + x_center_offset, pos.getY() + y_center_offset,
				pos.getZ() + z_center_offset) < maxinum_distance_sq;
	}

	public static boolean isValidForInputSlot(ItemStack itemStack) {
		return true;
	}

	public static boolean isValidForFuelSlot(ItemStack itemStack) {
		return true;
	}

	public static boolean isValidForOutputSlot(ItemStack itemStack) {
		return true;
	}

	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound parentNBTTagCompound) {
		super.writeToNBT(parentNBTTagCompound);
		NBTTagList dataForAllSlots = new NBTTagList();
		for (int i = 0; i < this.itemsInCrusher.length; i++) {
			if (this.itemsInCrusher != null) {
				NBTTagCompound dataForThisSlot = new NBTTagCompound();
				dataForThisSlot.setInteger("Slot", i);
				this.itemsInCrusher[i].writeToNBT(dataForThisSlot);
				dataForAllSlots.appendTag(dataForThisSlot);
			}
		}
		parentNBTTagCompound.setTag("Items", dataForAllSlots);
		parentNBTTagCompound.setInteger("CookTime", cookTime);
		parentNBTTagCompound.setTag("burnTimeRemaining", new NBTTagIntArray(burnTimeRemaining));
		parentNBTTagCompound.setInteger("cookTimeNeeded", cookTimeNeeded);
		return parentNBTTagCompound;
	}

	@Override
	public void readFromNBT(NBTTagCompound nbtTagCompound) {
		super.readFromNBT(nbtTagCompound);
		int nbt_type_compound = 10;
		NBTTagList dataForAllSlots = nbtTagCompound.getTagList("Items", nbt_type_compound);
		Arrays.fill(itemsInCrusher, null);
		for (int i = 0; i < dataForAllSlots.tagCount(); i++) {
			NBTTagCompound dataForOneSlot = dataForAllSlots.getCompoundTagAt(i);
			int slotNumber = dataForOneSlot.getInteger("Slot");
			if (slotNumber >= 0 && slotNumber < this.itemsInCrusher.length) {
				this.itemsInCrusher[slotNumber] = ItemStack.loadItemStackFromNBT(dataForOneSlot);
			}
			cookTime = nbtTagCompound.getInteger("CookTime");
			burnTimeRemaining = Arrays.copyOf(nbtTagCompound.getIntArray("burnTimeRemaining"), fuel_slots);
			cookTimeNeeded = nbtTagCompound.getInteger("cookTimeNeeded");
			cachedNumberOfBurningSlots = -1;
		}
	}

	public Packet getDescriptionPacket() {
		NBTTagCompound NBTTagCompound = new NBTTagCompound();
		writeToNBT(NBTTagCompound);
		int metadata = 0;
		return new SPacketUpdateTileEntity(this.pos, metadata, NBTTagCompound);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasCustomName() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ITextComponent getDisplayName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemStack removeStackFromSlot(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void openInventory(EntityPlayer player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeInventory(EntityPlayer player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getField(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setField(int id, int value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getFieldCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	
	
*/
}