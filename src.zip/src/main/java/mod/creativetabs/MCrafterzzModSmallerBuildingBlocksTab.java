package mod.creativetabs;

import mod.ModElements;
import mod.ModElementsSmallerBlocks;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class MCrafterzzModSmallerBuildingBlocksTab extends CreativeTabs {

	public MCrafterzzModSmallerBuildingBlocksTab(String label) {
		super(label);
	}

	@Override
	public Item getTabIconItem() {
		return Item.getItemFromBlock(ModElementsSmallerBlocks.sandy_stone_bricks_wall);
	}

}
