package mod;

public class Reference {
	public static final String modid = "mm";
	public static final String name = "MCrafterzz mod";
	public static final String mcversion = "1.10.2";
	public static final String version = "3.6.1";
	public static final String creator = "MCrafterzz";
	public static final String update_page = "http://minecraft.curseforge.com/projects/mcrafterzz-mod/";

	public static final String clientproxy = "mod.proxy.ClientProxy";
	public static final String commonproxy = "mod.proxy.CommonProxy";
}
